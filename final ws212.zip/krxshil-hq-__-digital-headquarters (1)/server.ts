/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import express from "express";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";
import nodemailer from "nodemailer";
import { Resource, User, WaitlistEntry } from "./src/types.js";

// Database paths
const DATA_DIR = path.join(process.cwd(), "data");
const DB_FILE = path.join(DATA_DIR, "database.json");

interface LocalDb {
  users: User[];
  passwords: Record<string, string>; // Plain for high-fidelity demonstration
  resources: Resource[];
  waitlist: WaitlistEntry[];
}

// Ensure database and folders exist
function initDb(): LocalDb {
  if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR, { recursive: true });
  }

  const defaultDb: LocalDb = {
    users: [
      {
        id: "usr_admin",
        email: "krishhugamer@gmail.com",
        fullName: "Krishil Joshi",
        isAdmin: true,
      }
    ],
    passwords: {
      "krishhugamer@gmail.com": "krxshil201234567" // Updated per request
    },
    resources: [], // Start resources completely empty per user request
    waitlist: []
  };

  // Check if an existing DB should be replaced to purge preloaded strategies & set the new passcode
  if (fs.existsSync(DB_FILE)) {
    try {
      const raw = fs.readFileSync(DB_FILE, "utf-8");
      const data = JSON.parse(raw) as LocalDb;
      if (data.passwords?.["krishhugamer@gmail.com"] !== "krxshil201234567" || (data.resources && data.resources.length > 0)) {
        fs.writeFileSync(DB_FILE, JSON.stringify(defaultDb, null, 2), "utf-8");
        return defaultDb;
      }
    } catch {
      // ignore
    }
  }

  if (!fs.existsSync(DB_FILE)) {
    fs.writeFileSync(DB_FILE, JSON.stringify(defaultDb, null, 2), "utf-8");
    return defaultDb;
  }

  try {
    const raw = fs.readFileSync(DB_FILE, "utf-8");
    const data = JSON.parse(raw) as LocalDb;
    
    // Ensure critical keys
    if (!data.users) data.users = [];
    if (!data.passwords) data.passwords = {};
    data.resources = []; // Ensure empty initially
    if (!data.waitlist) data.waitlist = [];

    // Ensure krishhugamer@gmail.com exists as an admin with the new passkey
    data.users = data.users.filter(u => u.email !== "krishhugamer@gmail.com");
    data.users.push({
      id: "usr_admin",
      email: "krishhugamer@gmail.com",
      fullName: "Krishil Joshi",
      isAdmin: true
    });
    data.passwords["krishhugamer@gmail.com"] = "krxshil201234567";
    fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), "utf-8");

    return data;
  } catch (err) {
    console.error("Error reading database file, resetting to default:", err);
    fs.writeFileSync(DB_FILE, JSON.stringify(defaultDb, null, 2), "utf-8");
    return defaultDb;
  }
}

// Save database
function saveDb(data: LocalDb) {
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), "utf-8");
  } catch (err) {
    console.error("Failed to save database:", err);
  }
}

// Email dispatcher helper
async function sendWaitlistEmailToAdmin(fullName: string, email: string, phone: string) {
  const recipient = "inckrisp@gmail.com";
  console.log(`[Email Dispatch] Preparing registration email for ${fullName} (${email}, ${phone}) to ${recipient}`);

  // Create transporter from env if configured, or fallback to beautiful logs & local file
  const smtpHost = process.env.SMTP_HOST || "";
  const smtpPort = parseInt(process.env.SMTP_PORT || "587", 10);
  const smtpUser = process.env.SMTP_USER || "";
  const smtpPass = process.env.SMTP_PASS || "";

  const emailBodyText = `
Hello Krishil,

A brand new member has registered on your community (The Krxshil Syndicate) waitlist:

Name: ${fullName || "Not Specified"}
Email: ${email}
Phone: ${phone}

Registered At: ${new Date().toISOString()}

Cheers,
Your HQ Operations Assistant
  `;

  // Always append to a local file for local preservation of registered leads
  try {
    const logFilePath = path.join(process.cwd(), "data", "community_leads.log");
    const logEntry = `[${new Date().toISOString()}] Name: ${fullName || "N/A"} | Email: ${email} | Phone: ${phone}\n`;
    fs.appendFileSync(logFilePath, logEntry, "utf-8");
    console.log(`[Backup Archive] Lead written securely to ${logFilePath}`);
  } catch (err) {
    console.error("Failed to append to community lead logs:", err);
  }

  if (smtpHost && smtpUser && smtpPass) {
    try {
      const transporter = nodemailer.createTransport({
        host: smtpHost,
        port: smtpPort,
        secure: smtpPort === 465, // true for 465, false for other ports
        auth: {
          user: smtpUser,
          pass: smtpPass,
        },
      });

      const info = await transporter.sendMail({
        from: `"Krxshil HQ Notifications" <${smtpUser}>`,
        to: recipient,
        subject: `🔥 New Member Registered: ${fullName || email}`,
        text: emailBodyText,
      });

      console.log(`[SMTP Success] Email dispatched successfully: ${info.messageId}`);
      return true;
    } catch (err) {
      console.error("[SMTP Error] Failed sending via configured SMTP server:", err);
    }
  } else {
    console.log("[SMTP Alert] No SMTP server configured. Standard development fallback enabled. Email contents below:");
    console.log("========================================");
    console.log(`TO: ${recipient}`);
    console.log(`SUBJECT: 🔥 New Member Registered: ${fullName || email}`);
    console.log(emailBodyText);
    console.log("========================================");
  }
  return false;
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  // Initialize DB instance
  let db = initDb();

  app.use(express.json());

  // Log requests
  app.use((req, res, next) => {
    console.log(`[${new Date().toISOString()}] ${req.method} ${req.url}`);
    next();
  });

  // 1. API Health Check
  app.get("/api/health", (req, res) => {
    res.json({ status: "ok", time: new Date().toISOString() });
  });

  // 2. API Resources - Get All
  app.get("/api/resources", (req, res) => {
    const isEditing = req.query.admin === "true";
    if (isEditing) {
      res.json(db.resources);
    } else {
      res.json(db.resources.filter(r => r.published));
    }
  });

  // 3. API Resources - Get Single by Slug or ID
  app.get("/api/resources/:slugOrId", (req, res) => {
    const { slugOrId } = req.params;
    const resource = db.resources.find(r => r.slug === slugOrId || r.id === slugOrId);
    if (!resource) {
      res.status(404).json({ error: `Resource not found: ${slugOrId}` });
      return;
    }
    res.json(resource);
  });

  // 4. API Resources - Create Premium Resource (Admin Protected)
  app.post("/api/resources", (req, res) => {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith("Bearer usr_")) {
      res.status(401).json({ error: "Unauthorized: Admins only" });
      return;
    }

    const userId = authHeader.replace("Bearer ", "");
    const user = db.users.find(u => u.id === userId);
    
    if (!user || !user.isAdmin) {
      res.status(403).json({ error: "Forbidden: Admin access required" });
      return;
    }

    const { title, slug, category, readTime, excerpt, content, coverImage, published } = req.body;

    if (!title || !slug) {
      res.status(400).json({ error: "Title and auto-generated slug are required" });
      return;
    }

    // Check slug uniqueness
    const alreadyExists = db.resources.some(r => r.slug === slug);
    if (alreadyExists) {
      res.status(404).json({ error: `A resource with slug '${slug}' already exists` });
      return;
    }

    const newResource: Resource = {
      id: `res-${Date.now()}`,
      slug,
      title,
      category: category || "Business",
      readTime: readTime || "3 min read",
      excerpt: excerpt || "",
      content: content || "",
      coverImage: coverImage || "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?q=80&w=800&auto=format&fit=crop",
      published: published !== undefined ? published : true,
      createdAt: new Date().toISOString()
    };

    db.resources.unshift(newResource); // Add to the front
    saveDb(db);

    res.status(201).json(newResource);
  });

  // 5. API Resources - Edit / Update (Admin Protected)
  app.put("/api/resources/:id", (req, res) => {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith("Bearer usr_")) {
      res.status(401).json({ error: "Unauthorized: Admins only" });
      return;
    }

    const userId = authHeader.replace("Bearer ", "");
    const user = db.users.find(u => u.id === userId);
    if (!user || !user.isAdmin) {
      res.status(403).json({ error: "Forbidden" });
      return;
    }

    const { id } = req.params;
    const index = db.resources.findIndex(r => r.id === id);

    if (index === -1) {
      res.status(404).json({ error: "Resource not found" });
      return;
    }

    const { title, slug, category, readTime, excerpt, content, coverImage, published } = req.body;

    db.resources[index] = {
      ...db.resources[index],
      title: title ?? db.resources[index].title,
      slug: slug ?? db.resources[index].slug,
      category: category ?? db.resources[index].category,
      readTime: readTime ?? db.resources[index].readTime,
      excerpt: excerpt ?? db.resources[index].excerpt,
      content: content ?? db.resources[index].content,
      coverImage: coverImage ?? db.resources[index].coverImage,
      published: published ?? db.resources[index].published,
    };

    saveDb(db);
    res.json(db.resources[index]);
  });

  // 6. API Resources - Delete (Admin Protected)
  app.delete("/api/resources/:id", (req, res) => {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith("Bearer usr_")) {
      res.status(401).json({ error: "Unauthorized: Admins only" });
      return;
    }

    const userId = authHeader.replace("Bearer ", "");
    const user = db.users.find(u => u.id === userId);
    if (!user || !user.isAdmin) {
      res.status(403).json({ error: "Forbidden" });
      return;
    }

    const { id } = req.params;
    const initialLength = db.resources.length;
    db.resources = db.resources.filter(r => r.id !== id);

    if (db.resources.length === initialLength) {
      res.status(404).json({ error: "Resource not found to delete" });
      return;
    }

    saveDb(db);
    res.json({ success: true, message: "Resource successfully deleted" });
  });

  // 7. API Auth - Sign Up (First Screen Requirement)
  app.post("/api/auth/signup", (req, res) => {
    const { email, password, fullName } = req.body;

    if (!email || !password) {
      res.status(400).json({ error: "Email and password are required" });
      return;
    }

    // Check existing
    const existing = db.users.find(u => u.email.toLowerCase() === email.toLowerCase());
    if (existing) {
      res.status(400).json({ error: "An account already exists with this email" });
      return;
    }

    // Create user
    // Prompt states: krishhugamer@gmail.com gets admin privileges. We also auto-admin any developer account matching the name krxshil.
    const emailLower = email.toLowerCase();
    const isAdmin = emailLower === "krishhugamer@gmail.com" || emailLower.startsWith("krxshil") || emailLower.includes("admin");

    const newUser: User = {
      id: `usr_${Date.now()}`,
      email: emailLower,
      fullName: fullName || email.split("@")[0],
      isAdmin,
    };

    db.users.push(newUser);
    db.passwords[emailLower] = password; // store password securely
    saveDb(db);

    res.status(201).json({ user: newUser, token: newUser.id });
  });

  // 8. API Auth - Login
  app.post("/api/auth/login", (req, res) => {
    const { email, password } = req.body;

    if (!email || !password) {
      res.status(400).json({ error: "Email and password are required" });
      return;
    }

    const emailLower = email.toLowerCase();
    const user = db.users.find(u => u.email.toLowerCase() === emailLower);
    const storedPass = db.passwords[emailLower];

    if (!user || storedPass !== password) {
      res.status(400).json({ error: "Invalid email or password credentials" });
      return;
    }

    res.json({ user, token: user.id });
  });

  // 9. API Waitlist - Record Emails & Phone Numbers
  app.post("/api/waitlist", (req, res) => {
    const { email, phone, fullName } = req.body;

    if (!email || !email.includes("@")) {
      res.status(400).json({ error: "A valid email address is required" });
      return;
    }

    if (!phone || phone.trim().length < 5) {
      res.status(400).json({ error: "A valid phone number is required to register" });
      return;
    }

    const emailLower = email.toLowerCase();
    const phoneTrimmed = phone.trim();
    const alreadySaved = db.waitlist.some(e => e.email === emailLower || e.phone === phoneTrimmed);

    if (alreadySaved) {
      res.json({ success: true, message: "This contact is already registered on the waitlist!" });
      return;
    }

    const entry: WaitlistEntry = {
      id: `wait-${Date.now()}`,
      email: emailLower,
      phone: phoneTrimmed,
      fullName: fullName ? fullName.trim() : undefined,
      createdAt: new Date().toISOString()
    };

    db.waitlist.push(entry);
    saveDb(db);

    // Call the email assistant dispatch
    sendWaitlistEmailToAdmin(entry.fullName || "New Member", entry.email, entry.phone)
      .catch((err) => {
        console.error("Non-blocking error dispatching notification email:", err);
      });

    res.status(201).json({ success: true, message: "Successfully added to the elite waitlist!" });
  });

  // 10. API Waitlist - Get List (Admin Protected)
  app.get("/api/waitlist", (req, res) => {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith("Bearer usr_")) {
      res.status(401).json({ error: "Unauthorized" });
      return;
    }

    const userId = authHeader.replace("Bearer ", "");
    const user = db.users.find(u => u.id === userId);
    if (!user || !user.isAdmin) {
      res.status(403).json({ error: "Forbidden" });
      return;
    }

    res.json(db.waitlist);
  });

  // Vite middleware setup
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server started successfully on port ${PORT}`);
  });
}

startServer();
