/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { Compass, Sparkles, BookOpen, Instagram, Share2, KeyRound, Terminal, ChevronRight, LockKeyhole } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

import Effects from "./components/Effects";
import Header from "./components/Header";
import ProfileWidget from "./components/ProfileWidget";
import ResourcesList from "./components/ResourcesList";
import ResourceView from "./components/ResourceView";
import AuthScreen from "./components/AuthScreen";
import AdminPanel from "./components/AdminPanel";
import { Resource, User } from "./types";

export default function App() {
  const [currentRoute, setCurrentRouteState] = useState<string>("home");
  const [selectedCategory, setSelectedCategory] = useState<string>("All");
  const [selectedSlug, setSelectedSlug] = useState<string | null>(null);

  const navigateTo = (route: string, replace = false) => {
    let targetPath = "/";
    if (route === "home") {
      targetPath = "/";
    } else if (route === "resources") {
      targetPath = "/resources";
    } else if (route === "admin") {
      targetPath = "/admin";
    } else if (route === "auth") {
      targetPath = "/auth";
    } else if (route.startsWith("resource-detail-")) {
      const slug = route.replace("resource-detail-", "");
      targetPath = `/${slug}`;
    }

    setCurrentRouteState(route);

    if (route.startsWith("resource-detail-")) {
      const slug = route.replace("resource-detail-", "");
      setSelectedSlug(slug);
    } else {
      setSelectedSlug(null);
    }

    if (window.location.pathname !== targetPath) {
      if (replace) {
        window.history.replaceState({ route }, "", targetPath);
      } else {
        window.history.pushState({ route }, "", targetPath);
      }
    }
  };

  const setCurrentRoute = (route: string) => navigateTo(route);

  // Authentication State
  const [user, setUser] = useState<User | null>(null);
  const [userToken, setUserToken] = useState<string>("");

  // Resource Database States
  const [resources, setResources] = useState<Resource[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Rotating words trigger
  const rotatingWords = ["Sales", "Business", "Growth", "Building", "Creating"];
  const [wordIdx, setWordIdx] = useState(0);

  useEffect(() => {
    const wordInterval = setInterval(() => {
      setWordIdx((prev) => (prev + 1) % rotatingWords.length);
    }, 2400);

    return () => clearInterval(wordInterval);
  }, []);

  // Sync token on startup from localStorage (Session preserve)
  useEffect(() => {
    const sessionToken = localStorage.getItem("krxshil_sess_token");
    const sessionEmail = localStorage.getItem("krxshil_sess_email");
    const sessionName = localStorage.getItem("krxshil_sess_name");
    const sessionIsAdmin = localStorage.getItem("krxshil_sess_is_admin") === "true";

    if (sessionToken && sessionEmail) {
      setUser({
        id: sessionToken,
        email: sessionEmail,
        fullName: sessionName || "",
        isAdmin: sessionIsAdmin,
      });
      setUserToken(sessionToken);
    }
  }, []);

  // Synchronize browser URL pathname with App router state
  useEffect(() => {
    const handleLocationChange = () => {
      const path = window.location.pathname;
      if (path === "/" || path === "") {
        setCurrentRouteState("home");
        setSelectedSlug(null);
      } else if (path === "/admin" || path.endsWith("/admin")) {
        setCurrentRouteState("admin");
        setSelectedSlug(null);
      } else if (path === "/resources" || path.endsWith("/resources")) {
        setCurrentRouteState("resources");
        setSelectedSlug(null);
      } else if (path === "/auth" || path.endsWith("/auth")) {
        setCurrentRouteState("auth");
        setSelectedSlug(null);
      } else {
        // Strip leading slash to get potential slug
        const slug = path.substring(1);
        if (slug) {
          setSelectedSlug(slug);
          setCurrentRouteState(`resource-detail-${slug}`);
        } else {
          setCurrentRouteState("home");
          setSelectedSlug(null);
        }
      }
    };

    // Run once on load
    handleLocationChange();

    // Listen to standard browser Back/Forward (popstate)
    window.addEventListener("popstate", handleLocationChange);
    return () => {
      window.removeEventListener("popstate", handleLocationChange);
    };
  }, []);

  // Fetch strategies
  useEffect(() => {
    const fetchResources = async () => {
      setIsLoading(true);
      try {
        // Query resources. Pass ?admin=true if they are an admin
        const isAdminSess = localStorage.getItem("krxshil_sess_is_admin") === "true";
        const url = isAdminSess ? "/api/resources?admin=true" : "/api/resources";
        
        const res = await fetch(url);
        if (res.ok) {
          const data = await res.json();
          setResources(data);
        }
      } catch (err) {
        console.error("Failed to query strategies list:", err);
      } finally {
        setIsLoading(false);
      }
    };
    fetchResources();
  }, [user]);

  // Auth session callbacks
  const handleAuthSuccess = (session: { user: User; token: string }) => {
    setUser(session.user);
    setUserToken(session.token);
    
    localStorage.setItem("krxshil_sess_token", session.token);
    localStorage.setItem("krxshil_sess_email", session.user.email);
    localStorage.setItem("krxshil_sess_name", session.user.fullName || "");
    localStorage.setItem("krxshil_sess_is_admin", String(session.user.isAdmin));
  };

  const handleLogout = () => {
    setUser(null);
    setUserToken("");
    localStorage.removeItem("krxshil_sess_token");
    localStorage.removeItem("krxshil_sess_email");
    localStorage.removeItem("krxshil_sess_name");
    localStorage.removeItem("krxshil_sess_is_admin");
    setCurrentRoute("home");
  };

  const handleResourceSelect = (slug: string) => {
    setSelectedSlug(slug);
    setCurrentRoute(`resource-detail-${slug}`);
  };

  // Preloaded credentials tip
  const hasTipSeen = localStorage.getItem("krxshil_cred_tip");

  return (
    <div className="relative min-h-screen flex flex-col font-sans select-none bg-[#050505] text-white">
      {/* 1. Immersive Vector Particles & Spotlight Follower background */}
      <Effects />

      {/* 2. Frosted Header navigation bar */}
      <Header
        currentRoute={currentRoute}
        setCurrentRoute={setCurrentRoute}
        user={user}
        onLogout={handleLogout}
        setSelectedCategory={setSelectedCategory}
      />

      {/* 3. Main Route content workspace render */}
      <main className="flex-grow pt-16 pb-24 relative z-10 w-full" id="main-content-block">
        <AnimatePresence mode="wait">
          
          {/* A. Landing Page / Home Overview view */}
          {currentRoute === "home" && (
            <motion.div
              key="home-tab"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.6 }}
              className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 space-y-24"
            >
              
              {/* LANDING PAGE - Full screen dynamic premium hero */}
              <section className="relative flex flex-col items-center justify-center py-20 sm:py-28 text-center min-h-[50vh] overflow-hidden">

                <h1 className="font-display font-extrabold text-5xl sm:text-7xl lg:text-8xl tracking-tight leading-none text-white uppercase mb-4">
                  KRISHIL JOSHI
                </h1>

                {/* Subtitle with Rotating Key attributes */}
                <div className="flex flex-col sm:flex-row items-center font-mono text-base md:text-xl tracking-wider text-zinc-400 mb-10 h-10 select-none">
                  <span className="font-semibold text-zinc-200">@krxshil</span>
                  <span className="hidden sm:inline mx-3.5 text-zinc-650">//</span>
                  <div className="font-bold flex items-center space-x-1 leading-none uppercase">
                    <span className="text-zinc-500 mr-1.5">Focusing on:</span>
                    <AnimatePresence mode="wait">
                      <motion.span
                        key={wordIdx}
                        initial={{ y: 15, opacity: 0 }}
                        animate={{ y: 0, opacity: 1 }}
                        exit={{ y: -15, opacity: 0 }}
                        transition={{ duration: 0.3, ease: "easeOut" }}
                        className="text-yellow-400 glow-text-yellow"
                      >
                        {rotatingWords[wordIdx]}
                      </motion.span>
                    </AnimatePresence>
                  </div>
                </div>

                {/* Direct CTA controls */}
                <div className="flex flex-col sm:flex-row items-center justify-center gap-3.5 w-full max-w-xl mx-auto">
                  <button
                    onClick={() => {
                      setCurrentRoute("resources");
                    }}
                    className="w-full sm:w-auto px-6 py-3 bg-gradient-to-r from-yellow-400 to-yellow-500 hover:from-yellow-305 hover:to-yellow-410 text-black text-xs font-bold leading-none font-display tracking-wider rounded-xl uppercase shadow-[0_0_20px_rgba(234,179,8,0.4)] transition-all duration-300 active:scale-95"
                  >
                    Get Resources
                  </button>

                  <a
                    href="https://instagram.com/krxshil"
                    target="_blank"
                    rel="noreferrer"
                    className="w-full sm:w-auto flex items-center justify-center space-x-1.5 px-6 py-3 border border-white/5 bg-zinc-955 hover:bg-zinc-900 text-zinc-400 hover:text-white text-xs font-mono font-bold tracking-wider rounded-xl uppercase transition-all duration-200"
                  >
                    <Instagram className="w-3.5 h-3.5 text-pink-500/80" />
                    <span>Instagram</span>
                  </a>
                </div>
              </section>

              {/* Digital Assets shortcut teaser deck container */}
              <section className="py-12 border-t border-white/5 max-w-5xl mx-auto text-center" id="features-preview-cards">
                <div className="flex flex-col items-center justify-center mb-8">
                  <span className="font-mono text-[9px] text-[#fbbf24] font-semibold tracking-widest uppercase mb-1">
                    ⚡ KNOWLEDGE OVERVIEW
                  </span>
                  <h3 className="font-display font-black text-xl text-white uppercase tracking-tight">
                    7 Figure Sales Playbook
                  </h3>
                </div>

                <div className="max-w-xl mx-auto flex justify-center">
                  <div 
                    onClick={() => setCurrentRoute("resources")} 
                    className="relative w-64 h-80 cursor-pointer group perspective-1000 my-4"
                  >
                    {/* The 3D Book Container */}
                    <div className="relative w-full h-full rounded-r-2xl bg-gradient-to-br from-yellow-500 via-amber-600 to-yellow-950 shadow-[0_15px_35px_rgba(0,0,0,0.6)] border-y border-r border-white/15 transition-all duration-500 ease-out group-hover:-translate-y-3 group-hover:rotate-[-2deg] group-hover:shadow-[0_25px_50px_rgba(234,179,8,0.3)] flex flex-col justify-between p-6 overflow-hidden">
                      
                      {/* Page layers effect on the right edge to give paper thickness */}
                      <div className="absolute right-0 top-1 bottom-1 w-1.5 bg-zinc-100 rounded-l-sm shadow-inner transition-transform" />
                      <div className="absolute right-0.5 top-2 bottom-2 w-1 bg-zinc-200 rounded-l-sm transition-transform" />
                      
                      {/* Book spine indentation and highlighting overlay lines */}
                      <div className="absolute left-3.5 top-0 bottom-0 w-[2px] bg-black/35" />
                      <div className="absolute left-4 top-0 bottom-0 w-[1px] bg-white/20" />
                      
                      {/* Golden/Emerald Elegant badge on top */}
                      <div className="pl-4 text-left">
                        <span className="font-mono text-[8px] text-yellow-300 font-bold tracking-widest uppercase mb-1 block">
                          ★ VOL. I ★
                        </span>
                        <h4 className="font-display font-black text-xl text-white uppercase tracking-tight leading-tight group-hover:text-amber-400 transition-colors duration-300 drop-shadow-md">
                          Secret Sauce 🍯
                        </h4>
                      </div>

                      {/* Golden design accent bar inside the page */}
                      <div className="pl-4 text-left my-2">
                        <div className="h-[2px] w-12 bg-amber-400/80 rounded" />
                      </div>

                      {/* Book description / abstract quote */}
                      <div className="pl-4 text-left flex-1 flex items-center">
                        <p className="font-sans text-[11px] font-medium text-yellow-50 leading-relaxed drop-shadow italic">
                          "All the secrets that help me make a shit ton of cash in sales"
                        </p>
                      </div>

                      {/* Corner brand credit or vector asset element inside the cover */}
                      <div className="pl-4 flex items-center justify-between mt-4">
                        <span className="font-mono text-[7.5px] text-yellow-300 font-bold tracking-wider">
                          BY KRISHIL JOSHI
                        </span>
                        <BookOpen className="w-4 h-4 text-yellow-400 group-hover:scale-110 group-hover:text-amber-400 transition-all duration-300" />
                      </div>

                      {/* Elegant ambient light-reflection sheen */}
                      <div className="absolute inset-0 bg-gradient-to-tr from-white/0 via-white/5 to-white/10 pointer-events-none" />
                    </div>

                    {/* Classic leather-inspired ribbon bookmark dripping down the bottom */}
                    <div className="absolute left-10 bottom-[-10px] w-3.5 h-6 bg-gradient-to-b from-amber-500 to-amber-600 rounded-b transition-all duration-300 group-hover:h-8 group-hover:from-amber-400 group-hover:to-amber-500 origin-top shadow-md z-10" />
                  </div>
                </div>
              </section>

            </motion.div>
          )}

          {/* B. Resources Section list view */}
          {currentRoute === "resources" && (
            <motion.div
              key="resources-tab"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.5 }}
              className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8"
            >
              <ResourcesList
                resources={resources}
                isLoading={isLoading}
                selectedCategory={selectedCategory}
                setSelectedCategory={setSelectedCategory}
                onResourceSelect={handleResourceSelect}
                onEnterAuth={() => setCurrentRoute("auth")}
                isAuthenticated={!!user}
              />
            </motion.div>
          )}

          {/* C. Dynamic Individual Resource Reader (Route: /resources/:slug) */}
          {currentRoute.startsWith("resource-detail-") && isLoading && (
            <motion.div
              key="reader-loading"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              className="flex flex-col items-center justify-center py-24 text-center"
            >
              <div className="w-8 h-8 rounded-full border-2 border-yellow-500/20 border-t-yellow-400 animate-spin mb-4" />
              <span className="font-mono text-zinc-500 text-xs tracking-wider uppercase">Loading Premium Strategy...</span>
            </motion.div>
          )}

          {currentRoute.startsWith("resource-detail-") && !isLoading && !resources.some(r => `resource-detail-${r.slug}` === currentRoute) && (
            <motion.div
              key="reader-404"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="max-w-md mx-auto py-16 px-6 text-center glass-panel border-white/5 bg-zinc-950/40 rounded-2xl relative overflow-hidden"
            >
              <div className="absolute -top-10 -right-10 w-24 h-24 bg-yellow-400/5 rounded-full filter blur-xl" />
              <div className="font-mono text-xs text-yellow-500 font-bold uppercase tracking-wider mb-2">● PAGE NOT FOUND</div>
              <h3 className="font-display font-black text-xl text-white uppercase tracking-tight mb-3">Strategy Archive Missing</h3>
              <p className="font-sans text-xs text-zinc-500 mb-6 leading-relaxed">
                The playbook node you are requesting either doesn't exist, has been archived, or requires elevated authorization.
              </p>
              <button
                onClick={() => setCurrentRoute("resources")}
                className="px-5 py-2 bg-gradient-to-r from-yellow-400 to-yellow-500 hover:from-yellow-350 hover:to-yellow-400 text-black text-[10px] font-bold font-display tracking-widest rounded-lg uppercase shadow-[0_0_15px_rgba(234,179,8,0.2)] transition-all duration-200"
              >
                RETURN TO HQ OVERVIEW
              </button>
            </motion.div>
          )}

          {resources.map((res) => {
            const isCurrent = currentRoute === `resource-detail-${res.slug}`;
            if (!isCurrent) return null;
            return (
              <motion.div
                key={`resource-reader-${res.id}`}
                initial={{ opacity: 0, scale: 0.99 }}
                animate={{ opacity: 1, scale: 1 }}
                exit={{ opacity: 0, scale: 0.99 }}
                transition={{ duration: 0.4 }}
                className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8"
              >
                <ResourceView
                  resource={res}
                  onBack={() => setCurrentRoute("resources")}
                />
              </motion.div>
            );
          })}





          {/* E. Custom Authentication Screens (Gatekeeper) */}
          {currentRoute === "auth" && (
            <motion.div
              key="auth-tab"
              initial={{ opacity: 0, y: 15 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -15 }}
              transition={{ duration: 0.5 }}
              className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8"
            >
              <AuthScreen
                onAuthSuccess={handleAuthSuccess}
                setCurrentRoute={setCurrentRoute}
              />
            </motion.div>
          )}

          {/* F. Protected Admin Dashboard center console or explicit Login option */}
          {currentRoute === "admin" && (
            <motion.div
              key="admin-tab"
              initial={{ opacity: 0, scale: 1.01 }}
              animate={{ opacity: 1, scale: 1 }}
              exit={{ opacity: 0, scale: 1.01 }}
              transition={{ duration: 0.4 }}
              className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8"
            >
              {user && user.isAdmin ? (
                <AdminPanel
                  userToken={userToken}
                  onBack={() => setCurrentRoute("home")}
                  onLogout={handleLogout}
                  resources={resources}
                  setResources={setResources}
                />
              ) : (
                <div className="max-w-md mx-auto py-12 px-6 rounded-2xl glass-panel border-white/5 bg-zinc-950/60 relative overflow-hidden">
                  <div className="absolute -top-10 -right-10 w-32 h-32 bg-yellow-500/5 rounded-full filter blur-2xl pointer-events-none" />
                  <div className="absolute -bottom-10 -left-10 w-32 h-32 bg-amber-500/5 rounded-full filter blur-2xl pointer-events-none" />

                  <div className="mb-6 text-center">
                    <div className="inline-flex p-3 rounded-full bg-yellow-500/10 border border-yellow-500/20 text-[#fbbf24] mb-3">
                      <LockKeyhole className="w-6 h-6" />
                    </div>
                    <h2 className="font-display font-bold text-2xl text-white uppercase tracking-tight">
                      Admin Portal
                    </h2>
                    <p className="font-sans text-xs text-zinc-500 mt-1 font-light">
                      Please sign in to access Krishil Joshi's operations database.
                    </p>
                  </div>

                  {/* High fidelity inline login option form */}
                  <form 
                    onSubmit={async (e) => {
                      e.preventDefault();
                      const form = e.currentTarget;
                      const emailInput = form.elements.namedItem("admin-email") as HTMLInputElement;
                      const passInput = form.elements.namedItem("admin-pass") as HTMLInputElement;
                      
                      const errorDiv = document.getElementById("admin-login-error");
                      if (errorDiv) errorDiv.innerText = "";
                      
                      try {
                        const res = await fetch("/api/auth/login", {
                          method: "POST",
                          headers: { "Content-Type": "application/json" },
                          body: JSON.stringify({ 
                            email: emailInput.value, 
                            password: passInput.value 
                          }),
                        });
                        
                        const data = await res.json();
                        if (!res.ok) {
                          throw new Error(data.error || "Invalid credentials");
                        }
                        
                        handleAuthSuccess(data);
                      } catch (err: any) {
                        if (errorDiv) errorDiv.innerText = err.message || "Invalid criteria";
                      }
                    }} 
                    className="space-y-4"
                  >
                    <div id="admin-login-error" className="font-mono text-[10px] text-red-400 text-center uppercase tracking-wider" />

                    <div className="flex flex-col space-y-1">
                      <label className="font-mono text-[9px] uppercase tracking-widest text-[#fbbf24] text-left">Email Address</label>
                      <input
                        name="admin-email"
                        type="email"
                        required
                        placeholder="krishhugamer@gmail.com"
                        className="w-full bg-black/60 border border-white/5 focus:border-yellow-500/50 rounded-lg px-3 py-2 text-xs text-white focus:outline-none placeholder-zinc-700 font-mono"
                      />
                    </div>

                    <div className="flex flex-col space-y-1">
                      <label className="font-mono text-[9px] uppercase tracking-widest text-[#fbbf24] text-left">Password</label>
                      <input
                        name="admin-pass"
                        type="password"
                        required
                        placeholder="••••••••"
                        className="w-full bg-black/60 border border-[#18181b]/5 hover:border-yellow-500/10 focus:border-yellow-500/50 rounded-lg px-3 py-2 text-xs text-white focus:outline-none placeholder-zinc-700 font-mono"
                      />
                    </div>

                    <button
                      type="submit"
                      className="w-full py-2.5 bg-gradient-to-r from-yellow-400 to-yellow-500 hover:from-yellow-350 hover:to-yellow-400 text-black text-xs font-bold font-display tracking-wider rounded-lg uppercase shadow-[0_0_15px_rgba(234,179,8,0.3)] transition-all duration-200"
                    >
                      Authenticate Access
                    </button>
                  </form>
                </div>
              )}
            </motion.div>
          )}

        </AnimatePresence>
      </main>

      {/* 4. Luxury Digital Copyright Indicator footer */}
      <footer className="py-8 border-t border-white/5 relative z-14 font-mono text-[9px] text-zinc-600 text-center select-none pb-24 md:pb-8">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex flex-col items-center sm:items-start space-y-0.5">
            <span className="uppercase tracking-widest font-bold text-zinc-400">KRISHIL JOSHI © 2026</span>
            <span className="tracking-wide">MANAGEMENT & BRAND CONSULTANCY</span>
          </div>

          <div className="flex space-x-4">
            <a href="https://instagram.com/krxshil" target="_blank" rel="noreferrer" className="hover:text-yellow-400 transition-colors">INSTAGRAM</a>
            <span className="text-zinc-800">|</span>
            <span className="text-yellow-500/70 select-none">ALL RIGHTS RESERVED</span>
          </div>
        </div>
      </footer>
    </div>
  );
}
