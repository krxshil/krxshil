/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { Users, Mail, Compass, Star, ChevronRight, CheckCircle2, ShieldAlert, Phone, User as UserIcon } from "lucide-react";
import { motion } from "motion/react";

export default function WaitlistForm() {
  const [email, setEmail] = useState("");
  const [phone, setPhone] = useState("");
  const [fullName, setFullName] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");
  const [stats, setStats] = useState({ count: 482, spots: 18 });

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setErrorMsg("");
    setSuccess(false);

    try {
      const res = await fetch("/api/waitlist", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, phone, fullName }),
      });

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || "Waitlist registry failure");
      }

      setSuccess(true);
      setEmail("");
      setPhone("");
      setFullName("");
      // Increment stats slightly to reflect immediate participation
      setStats((prev) => ({ count: prev.count + 1, spots: Math.max(0, prev.spots - 1) }));
    } catch (err: any) {
      setErrorMsg(err.message || "Network sync failure");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto px-4 py-12 text-center" id="community-waitlist-container">
      {/* Glow Backing Element */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-72 h-72 rounded-full bg-amber-500/5 filter blur-3xl pointer-events-none" />

      {/* Flag */}
      <motion.div
        initial={{ opacity: 0, y: -10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6 }}
        className="inline-flex items-center space-x-1.5 px-3 py-1 border border-amber-500/20 bg-amber-950/20 text-amber-500 font-mono text-[9px] font-bold uppercase tracking-widest rounded-full mb-6"
      >
        <Star className="w-3 h-3 text-amber-400 fill-amber-400 animate-pulse" />
        <span>INNER CIRCLE PORTAL</span>
      </motion.div>

      {/* Main Headers */}
      <motion.h1
        initial={{ opacity: 0, scale: 0.98 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.8 }}
        className="font-display font-extrabold text-3xl sm:text-4xl text-white uppercase tracking-tight mb-3"
      >
        THE KRXSHIL SYNDICATE
      </motion.h1>

      <motion.p
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.8, delay: 0.1 }}
        className="font-mono text-xs text-amber-400 uppercase tracking-widest font-semibold mb-6 glow-text-gold"
      >
        COMING SOON // BATCH #1 REGISTRY OPEN
      </motion.p>

      <motion.p
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ duration: 0.8, delay: 0.15 }}
        className="font-sans text-xs text-zinc-500 font-light leading-relaxed max-w-md mx-auto mb-10"
      >
        A premium digital mastermind of high-ticket sales builders, builders, and Gen-Z creators. Master outbound mechanics and operational scale rules directly inside an active community.
      </motion.p>

      {/* Elite Queue Status Widgets */}
      <motion.div
        initial={{ opacity: 0, y: 10 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.6, delay: 0.2 }}
        className="grid grid-cols-2 gap-4 max-w-sm mx-auto mb-10 text-center"
      >
        <div className="glass-panel border-white/5 bg-zinc-950/40 p-4 rounded-xl">
          <span className="font-mono text-[9px] text-zinc-500 uppercase tracking-wider block mb-1">REGISTERED MEMBERS</span>
          <span className="font-display font-bold text-xl text-white">{stats.count}</span>
        </div>
        <div className="glass-panel border-white/5 bg-zinc-950/40 p-4 rounded-xl">
          <span className="font-mono text-[9px] text-zinc-500 uppercase tracking-wider block mb-1">AVAILABLE SPOT CODES</span>
          <span className="font-display font-bold text-xl text-amber-400 glow-text-gold animate-pulse">{stats.spots}</span>
        </div>
      </motion.div>

      {/* Interactive Registration Input Card */}
      <motion.div
        initial={{ opacity: 0, y: 15 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.8, delay: 0.25 }}
        className="glass-panel rounded-2xl border-amber-500/10 p-6 sm:p-8 bg-zinc-950/50 backdrop-blur-md max-w-md mx-auto shadow-2xl relative overflow-hidden"
      >
        {success ? (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            className="flex flex-col items-center justify-center text-center py-4"
          >
            <CheckCircle2 className="w-12 h-12 text-amber-500 mb-4 animate-bounce" />
            <h3 className="font-display font-bold text-base text-white uppercase mb-1">INDEX REGISTERED</h3>
            <span className="font-mono text-[10px] text-amber-400 uppercase tracking-wider block mb-2">ACCESS PASS SENT</span>
            <p className="font-sans text-xs text-zinc-400 font-light leading-relaxed max-w-xs">
              Check your inbox shortly. You've successfully secured a primary sequence queue node. Welcome to the group.
            </p>
          </motion.div>
        ) : (
          <form onSubmit={handleRegister} className="space-y-4">
            
            {/* Error notifications */}
            {errorMsg && (
              <div className="p-3 bg-red-950/20 border border-red-500/20 rounded-lg flex items-start space-x-2 text-left">
                <ShieldAlert className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
                <span className="font-sans text-xs text-red-400 font-light leading-relaxed">
                  {errorMsg}
                </span>
              </div>
            )}

            <div className="flex flex-col space-y-1.5 text-left">
              <label className="font-mono text-[9px] uppercase tracking-widest text-[#d97706] font-semibold">YOUR NAME</label>
              <div className="relative">
                <UserIcon className="absolute left-3 top-2.5 w-4 h-4 text-zinc-600" />
                <input
                  type="text"
                  required
                  value={fullName}
                  onChange={(e) => setFullName(e.target.value)}
                  placeholder="e.g. VIcky Koshal"
                  className="w-full bg-black/60 border border-white/5 focus:border-amber-500/40 rounded-lg pl-9 pr-4 py-2 text-xs text-white focus:outline-none placeholder-zinc-700 font-mono transition-colors"
                />
              </div>
            </div>

            <div className="flex flex-col space-y-1.5 text-left">
              <label className="font-mono text-[9px] uppercase tracking-widest text-[#d97706] font-semibold">EMAIL ADDRESS</label>
              <div className="relative">
                <Mail className="absolute left-3 top-2.5 w-4 h-4 text-zinc-650" />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="enter.your.best.email@domain.com"
                  className="w-full bg-black/60 border border-white/5 focus:border-amber-500/40 rounded-lg pl-9 pr-4 py-2 text-xs text-white focus:outline-none placeholder-zinc-700 font-mono transition-colors"
                />
              </div>
            </div>

            <div className="flex flex-col space-y-1.5 text-left">
              <label className="font-mono text-[9px] uppercase tracking-widest text-[#d97706] font-semibold">PHONE NUMBER (REQUIRED)</label>
              <div className="relative">
                <Phone className="absolute left-3 top-2.5 w-4 h-4 text-zinc-650" />
                <input
                  type="tel"
                  required
                  value={phone}
                  onChange={(e) => setPhone(e.target.value)}
                  placeholder="e.g. +91 9876543212"
                  className="w-full bg-black/60 border border-white/5 focus:border-amber-500/40 rounded-lg pl-9 pr-4 py-2 text-xs text-white focus:outline-none placeholder-zinc-700 font-mono transition-colors"
                />
              </div>
            </div>

            <button
              type="submit"
              disabled={isLoading}
              className="w-full flex items-center justify-center space-x-2 py-2.5 border border-amber-500/20 hover:border-amber-500/50 bg-amber-500/10 hover:bg-amber-500/20 text-amber-400 font-display font-bold text-xs uppercase tracking-wider rounded-lg transition-all duration-300 disabled:opacity-40 select-none active:scale-98"
            >
              {isLoading ? (
                <span className="font-mono font-normal">SECURE REGISTERING...</span>
              ) : (
                <>
                  <span>REGISTER TO COMMUNITY</span>
                  <ChevronRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>
        )}
      </motion.div>
    </div>
  );
}
