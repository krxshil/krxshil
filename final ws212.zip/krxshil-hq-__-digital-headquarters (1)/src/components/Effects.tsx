/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useEffect, useState, useRef } from "react";
import { motion } from "motion/react";

interface Particle {
  id: number;
  x: number;
  y: number;
  size: number;
  speedY: number;
  speedX: number;
  opacity: number;
  type: "dot" | "bill" | "growthLine";
  rotateSpeed: number;
}

export default function Effects() {
  const [mousePos, setMousePos] = useState({ x: -100, y: -100 });
  const [targetMousePos, setTargetMousePos] = useState({ x: -100, y: -100 });
  const [particles, setParticles] = useState<Particle[]>([]);
  const requestRef = useRef<number | null>(null);

  // Smooth cursor follow (lerping)
  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      setTargetMousePos({ x: e.clientX, y: e.clientY });
    };
    window.addEventListener("mousemove", handleMouseMove);
    return () => window.removeEventListener("mousemove", handleMouseMove);
  }, []);

  useEffect(() => {
    const updateCursor = () => {
      setMousePos((current) => {
        const dx = targetMousePos.x - current.x;
        const dy = targetMousePos.y - current.y;
        return {
          x: current.x + dx * 0.15,
          y: current.y + dy * 0.15,
        };
      });
      requestRef.current = requestAnimationFrame(updateCursor);
    };
    requestRef.current = requestAnimationFrame(updateCursor);
    return () => {
      if (requestRef.current) cancelAnimationFrame(requestRef.current);
    };
  }, [targetMousePos]);

  // Generate particles
  useEffect(() => {
    const pArray: Particle[] = [];
    const count = 35;
    for (let i = 0; i < count; i++) {
      pArray.push({
        id: i,
        x: Math.random() * 100,
        y: Math.random() * 100 + 100, // Start below screen or staggered
        size: Math.random() * 14 + (i % 3 === 0 ? 12 : 3), // some larger (bills), some smaller (dots)
        speedY: -(Math.random() * 0.8 + 0.3),
        speedX: (Math.random() - 0.5) * 0.4,
        opacity: Math.random() * 0.5 + 0.1,
        type: i % 4 === 0 ? "bill" : i % 5 === 0 ? "growthLine" : "dot",
        rotateSpeed: (Math.random() - 0.5) * 2,
      });
    }
    setParticles(pArray);

    const interval = setInterval(() => {
      setParticles((prev) =>
        prev.map((p) => {
          let nextY = p.y + p.speedY;
          let nextX = p.x + p.speedX;
          if (nextY < -10) {
            nextY = 110; // reset to bottom
            nextX = Math.random() * 100;
          }
          if (nextX < -5 || nextX > 105) {
            nextX = Math.random() * 100;
          }
          return {
            ...p,
            y: nextY,
            x: nextX,
          };
        })
      );
    }, 40);

    return () => clearInterval(interval);
  }, []);

  return (
    <div className="fixed inset-0 overflow-hidden pointer-events-none z-0">
      {/* 1. Deep Space Velvet Background */}
      <div className="absolute inset-0 bg-[#050505]" />

      {/* 2. Premium Radial Interactive Light Grid (Tech Grid) */}
      <div 
        className="absolute inset-0 opacity-15"
        style={{
          backgroundImage: `
            radial-gradient(circle at 1px 1px, rgba(255, 255, 255, 0.15) 1px, transparent 0),
            linear-gradient(to right, rgba(234, 179, 8, 0.02) 1px, transparent 1px),
            linear-gradient(to bottom, rgba(234, 179, 8, 0.02) 1px, transparent 1px)
          `,
          backgroundSize: "24px 24px, 48px 48px, 48px 48px",
        }}
      />

      {/* 3. Infinite Growth Grid Lines Map (Drifts upwards slightly) */}
      <div className="absolute bottom-0 left-0 w-full h-[600px] opacity-20 pointer-events-none">
        <svg width="100%" height="100%" viewBox="0 0 1440 600" fill="none" xmlns="http://www.w3.org/2000/svg">
          {/* Exponential Growth Chart Path Grid */}
          <path 
            d="M -100 620 Q 300 590 600 480 T 1100 250 T 1600 -50" 
            stroke="url(#emerald-glow-flow)" 
            strokeWidth="3" 
            fill="none" 
            className="opacity-60"
            style={{
              filter: "drop-shadow(0 0 15px rgba(234, 179, 8, 0.8))"
            }}
          />
          <path 
            d="M -100 640 Q 400 600 700 520 T 1200 320 T 1700 50" 
            stroke="url(#gold-glow-flow)" 
            strokeWidth="1.5" 
            fill="none" 
            className="opacity-45"
            style={{
              filter: "drop-shadow(0 0 10px rgba(245, 158, 11, 0.5))"
            }}
          />
          
          <defs>
            <linearGradient id="emerald-glow-flow" x1="0%" y1="100%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#eab308" stopOpacity="0.1" />
              <stop offset="50%" stopColor="#fbbf24" stopOpacity="0.5" />
              <stop offset="100%" stopColor="#fef08a" stopOpacity="0.9" />
            </linearGradient>
            <linearGradient id="gold-glow-flow" x1="0%" y1="100%" x2="100%" y2="0%">
              <stop offset="0%" stopColor="#d97706" stopOpacity="0.0" />
              <stop offset="40%" stopColor="#eab308" stopOpacity="0.4" />
              <stop offset="100%" stopColor="#fbbf24" stopOpacity="0.8" />
            </linearGradient>
          </defs>
        </svg>
      </div>

      {/* 4. Mouse-Responsive Halo Spotlight Glow (Cursor Follower) */}
      <div
        className="absolute w-[600px] h-[600px] rounded-full filter blur-[120px] opacity-25 mix-blend-screen transition-opacity duration-300 pointer-events-none"
        style={{
          left: `${mousePos.x - 300}px`,
          top: `${mousePos.y - 300}px`,
          background: "radial-gradient(circle, rgba(234,179,8,0.3) 0%, rgba(245,158,11,0.08) 50%, rgba(0,0,0,0) 70%)",
        }}
      />
      
      {/* 5. Fine golden ambient dot lighting source */}
      <div className="absolute top-1/4 right-1/4 w-[400px] h-[400px] rounded-full filter blur-[160px] opacity-[0.08] pointer-events-none bg-amber-500" />
      <div className="absolute bottom-1/4 left-1/4 w-[500px] h-[500px] rounded-full filter blur-[180px] opacity-[0.08] pointer-events-none bg-yellow-600" />

      {/* 6. Tasteful Dynamic Particles and Floating Money Elements */}
      {particles.map((p) => {
        if (p.type === "bill") {
          return (
            <div
              key={p.id}
              className="absolute select-none pointer-events-none text-emerald-500/25 filter drop-shadow-[0_0_8px_rgba(16,185,129,0.3)]"
              style={{
                left: `${p.x}%`,
                top: `${p.y}%`,
                transform: `scale(${p.size / 15}) rotate(${p.y * p.rotateSpeed}deg)`,
                opacity: p.opacity,
                transition: "transform 0.1s linear",
              }}
            >
              {/* Sleek Vector Mini-Dollar Icon Outline */}
              <svg width="40" height="24" viewBox="0 0 40 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="stroke-emerald-400">
                <rect x="1" y="1" width="38" height="22" rx="3" strokeWidth="1" fill="rgba(16,185,129,0.02)" />
                <circle cx="20" cy="12" r="6" strokeWidth="1" />
                <path d="M20 8V16M22 10.5C22 9.67 21.1 9 20 9C18.9 9 18 9.67 18 10.5C18 12 22 12 22 13.5C22 14.33 21.1 15 20 15C18.9 15 18 14.33 18 13.5" strokeWidth="1.2" strokeLinecap="round" strokeLinejoin="round" />
                <path d="M5 5L7 7M35 5L33 7M5 19L7 17M35 19L33 17" strokeWidth="0.8" />
              </svg>
            </div>
          );
        } else if (p.type === "growthLine") {
          return (
            <div
              key={p.id}
              className="absolute text-amber-500/15"
              style={{
                left: `${p.x}%`,
                top: `${p.y}%`,
                opacity: p.opacity * 0.5,
                transform: `scale(${p.size / 12})`,
              }}
            >
              <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg" className="stroke-amber-400">
                <path d="M23 6L13.5 15.5L8.5 10.5L1 18M23 6H17M23 6V12" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" />
              </svg>
            </div>
          );
        } else {
          return (
            <div
              key={p.id}
              className="absolute rounded-full bg-yellow-400/40"
              style={{
                left: `${p.x}%`,
                top: `${p.y}%`,
                width: `${p.size}px`,
                height: `${p.size}px`,
                opacity: p.opacity,
                boxShadow: p.size > 8 ? "0 0 10px rgba(234, 179, 8, 0.4)" : "none",
              }}
            />
          );
        }
      })}
    </div>
  );
}
