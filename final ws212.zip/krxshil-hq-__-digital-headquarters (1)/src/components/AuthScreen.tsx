/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from "react";
import { User, Mail, Lock, ShieldAlert, Sparkles, LogIn, ChevronRight, Check } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";

interface AuthScreenProps {
  onAuthSuccess: (user: any) => void;
  setCurrentRoute: (route: string) => void;
}

export default function AuthScreen({ onAuthSuccess, setCurrentRoute }: AuthScreenProps) {
  const [isSignUp, setIsSignUp] = useState(true); // Default MUST be Sign Up first
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [fullName, setFullName] = useState("");
  
  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");
  const [successMsg, setSuccessMsg] = useState("");

  const steps = [
    { label: "Create Account", desc: "Unlock elite credentials" },
    { label: "Access Resources", desc: "Instantly download tactics" },
    { label: "Join Community", desc: "Gain inner-circle invites" },
  ];

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMsg("");
    setSuccessMsg("");
    setIsLoading(true);

    const url = isSignUp ? "/api/auth/signup" : "/api/auth/login";
    const body = isSignUp ? { email, password, fullName } : { email, password };

    try {
      const res = await fetch(url, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
      });

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || "Authentication operation failed");
      }

      if (isSignUp) {
        setSuccessMsg("Account successfully provisioned! Access granted.");
        setTimeout(() => {
          onAuthSuccess(data);
          setCurrentRoute("resources"); // Send them straight to resources!
        }, 1200);
      } else {
        onAuthSuccess(data);
        setCurrentRoute("resources");
      }
    } catch (err: any) {
      setErrorMsg(err.message || "Network sync failure");
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-8 md:py-16" id="auth-flow-container">
      <div className="relative grid grid-cols-1 md:grid-cols-12 gap-8 items-stretch">
        
        {/* Left column: High-fidelity Flow visualization */}
        <div className="md:col-span-5 flex flex-col justify-center p-6 rounded-2xl glass-panel border-white/5 bg-black/60 relative overflow-hidden">
          <div className="absolute top-0 right-0 w-24 h-24 bg-yellow-500/5 rounded-full filter blur-xl pointer-events-none" />
          
          <div className="flex items-center space-x-1 font-mono text-[9px] text-yellow-400 font-bold tracking-widest uppercase mb-4">
            <Sparkles className="w-3.5 h-3.5" />
            <span>CRXSHIL ID SYSTEM</span>
          </div>

          <h3 className="font-display font-bold text-xl text-white uppercase mb-1">
            Access Protocol
          </h3>
          <p className="font-sans text-xs font-light text-zinc-400 leading-relaxed mb-8">
            Create an autonomous ID node to decode Krishil Joshi's active framework systems.
          </p>

          {/* Sequential Timeline Steps */}
          <div className="space-y-6">
            {steps.map((step, idx) => (
              <div key={idx} className="flex space-x-3.5 relative">
                {idx < steps.length - 1 && (
                  <div className="absolute left-[9px] top-6 bottom-[-24px] w-[1px] bg-zinc-800" />
                )}
                <div className={`w-[20px] h-[20px] rounded-full border flex items-center justify-center font-mono text-[9px] font-bold ${
                  idx === 0 
                    ? "bg-yellow-400 border-yellow-300 text-black shadow-[0_0_8px_rgba(234,179,8,0.5)]" 
                    : "border-zinc-800 text-zinc-500 bg-black/40"
                }`}>
                  {idx + 1}
                </div>
                <div>
                  <h4 className="font-display font-semibold text-xs text-zinc-200 uppercase tracking-wide">
                    {step.label}
                  </h4>
                  <p className="font-sans text-[10px] text-zinc-500 font-light mt-0.5">
                    {step.desc}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Right column: Beautiful Signup/Login Interactive form */}
        <div className="md:col-span-7 flex flex-col p-6 sm:p-8 rounded-2xl glass-panel border-white/5 bg-zinc-950/60 relative overflow-hidden">
          
          {/* Ambient Glows */}
          <div className="absolute -top-10 -right-10 w-32 h-32 bg-amber-500/5 rounded-full filter blur-2xl pointer-events-none" />
          <div className="absolute -bottom-10 -left-10 w-32 h-32 bg-yellow-500/5 rounded-full filter blur-2xl pointer-events-none" />

          {/* Core Title */}
          <div className="mb-6">
            <h2 className="font-display font-bold text-2xl text-white uppercase tracking-tight">
              {isSignUp ? "Create Account" : "Welcome Back"}
            </h2>
            <p className="font-sans text-xs text-zinc-500 mt-1 font-light">
              {isSignUp 
                ? "Prepare for high-leverage frameworks and core toolsets." 
                : "Resume terminal sessions and read published strategies."}
            </p>
          </div>

          <form onSubmit={handleSubmit} className="space-y-4">
            
            {/* Standard Error notice */}
            {errorMsg && (
              <motion.div 
                initial={{ opacity: 0, y: -4 }}
                animate={{ opacity: 1, y: 0 }}
                className="p-3 bg-red-950/20 border border-red-500/20 rounded-lg flex items-start space-x-2"
              >
                <ShieldAlert className="w-4 h-4 text-red-400 shrink-0 mt-0.5" />
                <span className="font-sans text-xs text-red-400 font-light leading-relaxed">
                  {errorMsg}
                </span>
              </motion.div>
            )}

            {/* Standard Success notice */}
            {successMsg && (
              <motion.div 
                initial={{ opacity: 0, y: -4 }}
                animate={{ opacity: 1, y: 0 }}
                className="p-3 bg-yellow-950/20 border border-yellow-500/20 rounded-lg flex items-start space-x-2"
              >
                <Check className="w-4 h-4 text-yellow-400 shrink-0 mt-0.5" />
                <span className="font-sans text-xs text-yellow-400 font-light leading-relaxed">
                  {successMsg}
                </span>
              </motion.div>
            )}

            {/* Full Name field (Only on Sign Up) */}
            {isSignUp && (
              <div className="flex flex-col space-y-1">
                <label className="font-mono text-[9px] uppercase tracking-widest text-zinc-500">FullName</label>
                <div className="relative">
                  <User className="absolute left-3 top-2.5 w-4 h-4 text-zinc-600" />
                  <input
                    type="text"
                    required
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    placeholder="e.g. Krishil Joshi"
                    className="w-full bg-black/60 border border-white/5 focus:border-yellow-500/50 rounded-lg pl-9 pr-4 py-2 text-xs text-white focus:outline-none placeholder-zinc-700 font-mono transition-colors"
                  />
                </div>
              </div>
            )}

            {/* Email field */}
            <div className="flex flex-col space-y-1">
              <label className="font-mono text-[9px] uppercase tracking-widest text-zinc-500">Secure Email</label>
              <div className="relative">
                <Mail className="absolute left-3 top-2.5 w-4 h-4 text-zinc-600" />
                <input
                  type="email"
                  required
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="email@email.com"
                  className="w-full bg-black/60 border border-white/5 focus:border-yellow-500/50 rounded-lg pl-9 pr-4 py-2 text-xs text-white focus:outline-none placeholder-zinc-700 font-mono transition-colors"
                />
              </div>
            </div>

            {/* Password field */}
            <div className="flex flex-col space-y-1">
              <div className="flex justify-between items-center">
                <label className="font-mono text-[9px] uppercase tracking-widest text-zinc-500">Secure Password</label>
                {!isSignUp && (
                  <span className="font-mono text-[9px] text-zinc-650 hover:text-amber-500 cursor-pointer">
                    Forgot Key?
                  </span>
                )}
              </div>
              <div className="relative">
                <Lock className="absolute left-3 top-2.5 w-4 h-4 text-zinc-600" />
                <input
                  type="password"
                  required
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="••••••••"
                  className="w-full bg-black/60 border border-white/5 focus:border-yellow-500/50 rounded-lg pl-9 pr-4 py-2 text-xs text-white focus:outline-none placeholder-zinc-700 font-mono transition-colors"
                />
              </div>
            </div>

            {/* CTA action Button */}
            <button
              type="submit"
              disabled={isLoading}
              className="w-full flex items-center justify-center space-x-2 py-2.5 border border-yellow-500/30 hover:border-yellow-500/60 bg-yellow-500/10 hover:bg-yellow-500/20 text-yellow-400 font-display font-bold text-xs uppercase tracking-wider rounded-lg transition-all duration-300 disabled:opacity-40 select-none active:scale-98"
            >
              {isLoading ? (
                <span className="font-mono font-normal">Authenticating Node...</span>
              ) : (
                <>
                  <span>{isSignUp ? "INITIALIZE ID SECRETS" : "SIGN SECURE SESSION"}</span>
                  <ChevronRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>

          {/* Bottom Switch Toggle */}
          <div className="mt-6 pt-5 border-t border-white/5 flex flex-col items-center justify-center space-y-2 text-center text-[10px] font-mono">
            {isSignUp ? (
              <div className="text-zinc-500">
                Already have an account?{" "}
                <button
                  onClick={() => setIsSignUp(false)}
                  className="text-amber-400 font-bold hover:underline ml-1"
                >
                  Login
                </button>
              </div>
            ) : (
              <div className="text-zinc-500">
                Don't have credentials?{" "}
                <button
                  onClick={() => setIsSignUp(true)}
                  className="text-yellow-400 font-bold hover:underline ml-1"
                >
                  Create Account
                </button>
              </div>
            )}
            
          </div>

        </div>

      </div>
    </div>
  );
}
