/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { motion } from "motion/react";

export default function ProfileWidget() {
  const tags = [
    { name: "Sales", color: "from-yellow-500/20 to-yellow-400/10 border-yellow-500/40 text-yellow-400 font-bold" },
    { name: "Business", color: "from-yellow-500/20 to-yellow-400/10 border-yellow-500/40 text-yellow-400 font-bold" },
    { name: "Growth", color: "from-yellow-500/20 to-yellow-400/10 border-yellow-500/40 text-yellow-400 font-bold" },
    { name: "Building", color: "from-yellow-500/20 to-yellow-400/10 border-yellow-500/40 text-yellow-400 font-bold" },
  ];

  const containerVariants = {
    hidden: { opacity: 0, y: 15 },
    visible: {
      opacity: 1,
      y: 0,
      transition: {
        staggerChildren: 0.1,
        ease: "easeOut",
        duration: 0.8,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 10 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.5 } },
  };

  return (
    <motion.div
      variants={containerVariants}
      initial="hidden"
      whileInView="visible"
      viewport={{ once: true, margin: "-100px" }}
      className="relative flex flex-col items-center justify-center text-center p-8 rounded-2xl glass-panel max-w-sm mx-auto overflow-hidden border-white/5 shadow-2xl group"
      id="profile-section"
    >
      {/* 3D Depth Spotlight Glow */}
      <div className="absolute inset-0 bg-gradient-to-b from-yellow-500/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-700 pointer-events-none" />
      
      {/* Glow Rings behind Meta */}
      <div className="absolute top-12 left-1/2 -translate-x-1/2 w-48 h-48 rounded-full bg-yellow-500/10 filter blur-3xl pointer-events-none animate-pulse" />

      {/* Meta Text - No bios, no long fluff */}
      <motion.h2 
        variants={itemVariants}
        className="font-display font-bold text-2xl tracking-wide text-white uppercase mb-1"
      >
        KRISHIL JOSHI
      </motion.h2>

      <motion.p 
        variants={itemVariants}
        className="font-mono text-xs text-yellow-400 tracking-wider font-semibold mb-6 uppercase"
      >
        @krxshil
      </motion.p>

      {/* Animated Skill/Attribute Tags */}
      <motion.div 
        variants={itemVariants}
        className="flex flex-wrap justify-center gap-2"
      >
        {tags.map((tag, idx) => (
          <motion.div
            key={idx}
            whileHover={{ scale: 1.1, translateY: -2 }}
            className={`px-3 py-1 bg-gradient-to-br ${tag.color} border rounded-full text-[10px] uppercase font-mono tracking-wider shadow-lg`}
          >
            {tag.name}
          </motion.div>
        ))}
      </motion.div>
    </motion.div>
  );
}
