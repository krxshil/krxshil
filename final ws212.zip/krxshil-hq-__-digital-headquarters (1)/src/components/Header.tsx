/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { Compass, Instagram, BookOpen } from "lucide-react";
import { motion } from "motion/react";
import profileAvatar from "../assets/images/profile_avatar_1780330800264.png";

interface HeaderProps {
  currentRoute: string;
  setCurrentRoute: (route: string) => void;
  user: any;
  onLogout: () => void;
  setSelectedCategory: (cat: string) => void;
}

export default function Header({ currentRoute, setCurrentRoute, user, onLogout, setSelectedCategory }: HeaderProps) {
  const navItems = [
    { id: "home", label: "Overview", icon: Compass },
    { id: "resources", label: "Resources", icon: BookOpen },
  ];

  const handleNavClick = (id: string) => {
    if (id === "resources") {
      setSelectedCategory("All"); // Reset resource filter
    }
    setCurrentRoute(id);
  };

  return (
    <header className="sticky top-0 z-50 w-full glass-panel border-b border-white/5 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-12 flex items-center justify-between md:grid md:grid-cols-3">
        {/* Brand Signifier */}
        <div 
          onClick={() => setCurrentRoute("home")} 
          className="flex items-center space-x-2.5 cursor-pointer group justify-self-start"
          id="brand-logo"
        >
          <div className="w-6 h-6 rounded-full overflow-hidden border border-yellow-500/30 flex items-center justify-center bg-zinc-950 shadow-[0_0_10px_rgba(234,179,8,0.3)] group-hover:shadow-[0_0_15px_rgba(234,179,8,0.6)] group-hover:border-yellow-400 transition-all duration-300">
            <img src={profileAvatar} alt="Krishil" className="w-full h-full object-cover" />
          </div>
          <div className="flex flex-col">
            <span className="font-display font-bold text-xs tracking-wider text-white uppercase select-none">
              Krishil Joshi
            </span>
            <span className="font-mono text-[9px] -mt-1 text-yellow-400 font-semibold transition-colors duration-300">
              @krxshil
            </span>
          </div>
        </div>

        {/* Central Navigation Menu */}
        <nav className="hidden md:flex items-center space-x-1 glass-panel px-1.5 py-0.5 rounded-lg border-white/5 bg-black/40 justify-self-center">
          {navItems.map((item) => {
            const isActive = currentRoute === item.id || (item.id === "resources" && currentRoute.startsWith("resource-"));
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                onClick={() => handleNavClick(item.id)}
                className={`relative flex items-center space-x-1 px-3 py-1 text-xs font-medium rounded-md transition-all duration-200 select-none ${
                  isActive ? "text-white" : "text-zinc-500 hover:text-zinc-300"
                }`}
              >
                {isActive && (
                  <motion.div
                    layoutId="active-nav bg-yellow-500/10 border border-yellow-500/20"
                    className="absolute inset-0 bg-yellow-950/25 border border-yellow-500/20 rounded-md z-0"
                    transition={{ type: "spring", stiffness: 380, damping: 30 }}
                  />
                )}
                <Icon className={`w-3.5 h-3.5 z-10 transition-colors ${isActive ? 'text-yellow-400' : ''}`} />
                <span className="z-10">{item.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Action Controls & Auth states */}
        <div className="flex items-center space-x-3 justify-self-end">
          {/* Instagram Button */}
          <a
            href="https://instagram.com/krxshil"
            target="_blank"
            rel="noreferrer"
            className="flex items-center justify-center p-1.5 rounded-lg border border-white/5 bg-zinc-950 hover:bg-zinc-900 text-zinc-400 hover:text-amber-400 transition-all duration-200"
            title="Follow @krxshil on Instagram"
          >
            <Instagram className="w-3.5 h-3.5" />
          </a>
        </div>
      </div>

      {/* Mobile Sticky Tab bar */}
      <div className="md:hidden flex items-center justify-between px-6 py-1 bg-black/80 border-t border-white/5 backdrop-blur-md fixed bottom-0 left-0 right-0 z-50 h-14">
        {navItems.map((item) => {
          const isActive = currentRoute === item.id || (item.id === "resources" && currentRoute.startsWith("resource-"));
          const Icon = item.icon;
          return (
            <button
              key={item.id}
              onClick={() => handleNavClick(item.id)}
              className={`flex flex-col items-center justify-center space-y-0.5 py-1 px-4 rounded-lg transition-all duration-150 ${
                isActive ? "text-yellow-400" : "text-zinc-500"
              }`}
            >
              <Icon className="w-4 h-4" />
              <span className="text-[10px] font-medium tracking-wide font-sans">{item.label}</span>
            </button>
          );
        })}
      </div>
    </header>
  );
}
