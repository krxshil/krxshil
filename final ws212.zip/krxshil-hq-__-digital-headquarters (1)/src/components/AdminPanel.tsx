/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { PlusCircle, Edit3, Trash2, Mail, FileText, Check, AlertCircle, ToggleLeft, ToggleRight, Loader, Terminal, Users, ExternalLink, ChevronLeft } from "lucide-react";
import { motion } from "motion/react";
import { Resource, WaitlistEntry } from "../types";

interface AdminPanelProps {
  userToken: string;
  onBack: () => void;
  onLogout?: () => void;
  resources: Resource[];
  setResources: React.Dispatch<React.SetStateAction<Resource[]>>;
}

export default function AdminPanel({ userToken, onBack, onLogout, resources, setResources }: AdminPanelProps) {
  const [waitlist, setWaitlist] = useState<WaitlistEntry[]>([]);
  const [activeTab, setActiveTab] = useState<"resources" | "waitlist">("resources");

  const [isLoading, setIsLoading] = useState(false);
  const [successMsg, setSuccessMsg] = useState("");
  const [errorMsg, setErrorMsg] = useState("");

  // Admin community registration form states
  const [regName, setRegName] = useState("");
  const [regEmail, setRegEmail] = useState("");
  const [regPhone, setRegPhone] = useState("");
  const [isRegistering, setIsRegistering] = useState(false);
  const [regSuccess, setRegSuccess] = useState("");
  const [regError, setRegError] = useState("");

  const handleAdminRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsRegistering(true);
    setRegSuccess("");
    setRegError("");

    try {
      const res = await fetch("/api/waitlist", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: regEmail, phone: regPhone, fullName: regName }),
      });

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || "Failed to register user to waitlist");
      }

      setRegSuccess("New community member registered successfully!");
      setRegEmail("");
      setRegName("");
      setRegPhone("");
      fetchWaitlist(); // Sync queue
    } catch (err: any) {
      setRegError(err.message || "Registration sync failure");
    } finally {
      setIsRegistering(false);
    }
  };

  // Editor states
  const [isEditing, setIsEditing] = useState(false);
  const [currentEditId, setCurrentEditId] = useState<string | null>(null);

  const [title, setTitle] = useState("");
  const [slug, setSlug] = useState("");
  const [category, setCategory] = useState<any>("Sales");
  const [readTime, setReadTime] = useState("3 min read");
  const [excerpt, setExcerpt] = useState("");
  const [content, setContent] = useState("");
  const [coverImage, setCoverImage] = useState("https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&q=80&w=800");
  const [published, setPublished] = useState(true);

  // Pre-curated premium digital artwork covers from Unsplash
  const premiumCovers = [
    "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&q=80&w=800",
    "https://images.unsplash.com/photo-1639762681485-074b7f938ba0?auto=format&fit=crop&q=80&w=800",
    "https://images.unsplash.com/photo-1634017839464-5c339ebe3cb4?auto=format&fit=crop&q=80&w=800",
    "https://images.unsplash.com/photo-1635070041078-e363dbe005cb?auto=format&fit=crop&q=80&w=800",
    "https://images.unsplash.com/photo-1614741118887-7a4ee193a5fa?auto=format&fit=crop&q=80&w=800",
  ];

  // Auto slug generation helper
  const handleTitleChange = (val: string) => {
    setTitle(val);
    if (!isEditing) {
      const generatedSlug = val
        .toLowerCase()
        .replace(/[^a-z0-9\s-]/g, "") // remove special characters
        .replace(/\s+/g, "-") // replace spaces with hyphens
        .replace(/-+/g, "-"); // prevent multiple hyphens
      setSlug(generatedSlug);
    }
  };

  // Fetch Resources & Waitlist on mount
  useEffect(() => {
    fetchWaitlist();
  }, [userToken]);

  const fetchWaitlist = async () => {
    try {
      const res = await fetch("/api/waitlist", {
        headers: { Authorization: `Bearer ${userToken}` },
      });
      if (res.ok) {
        const data = await res.json();
        setWaitlist(data);
      }
    } catch (err) {
      console.error("Failed to fetch waitlist:", err);
    }
  };

  const handleCreateOrUpdate = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);
    setErrorMsg("");
    setSuccessMsg("");

    const payload = { title, slug, category, readTime, excerpt, content, coverImage, published };
    const method = isEditing ? "PUT" : "POST";
    const endpoint = isEditing ? `/api/resources/${currentEditId}` : "/api/resources";

    try {
      const res = await fetch(endpoint, {
        method,
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${userToken}`,
        },
        body: JSON.stringify(payload),
      });

      const data = await res.json();

      if (!res.ok) {
        throw new Error(data.error || "Save endpoint failed to respond successfully");
      }

      setSuccessMsg(isEditing ? "Resource successfully updated." : "Resource successfully published!");
      
      // Sync local state
      if (isEditing) {
        setResources(prev => prev.map(r => r.id === currentEditId ? data : r));
      } else {
        setResources(prev => [data, ...prev]);
      }

      // Reset form controls
      resetForm();
    } catch (err: any) {
      setErrorMsg(err.message || "Network credentials sync error");
    } finally {
      setIsLoading(false);
    }
  };

  const handleEditClick = (resource: Resource) => {
    setIsEditing(true);
    setCurrentEditId(resource.id);
    setTitle(resource.title);
    setSlug(resource.slug);
    setCategory(resource.category);
    setReadTime(resource.readTime);
    setExcerpt(resource.excerpt);
    setContent(resource.content);
    setCoverImage(resource.coverImage);
    setPublished(resource.published);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  const handleDeleteClick = async (id: string) => {
    if (!window.confirm("Are you absolutely sure you want to delete this resource permanently? This is irreversible.")) {
      return;
    }

    try {
      const res = await fetch(`/api/resources/${id}`, {
        method: "DELETE",
        headers: { Authorization: `Bearer ${userToken}` },
      });

      if (!res.ok) {
        throw new Error("Could not delete resource from server terminal");
      }

      setResources(prev => prev.filter(r => r.id !== id));
      setSuccessMsg("Resource node successfully cleared.");
    } catch (err: any) {
      setErrorMsg(err.message || "Deletion error");
    }
  };

  const resetForm = () => {
    setIsEditing(false);
    setCurrentEditId(null);
    setTitle("");
    setSlug("");
    setCategory("Sales");
    setReadTime("3 min read");
    setExcerpt("");
    setContent("");
    setCoverImage(premiumCovers[0]);
    setPublished(true);
  };

  return (
    <div className="max-w-6xl mx-auto px-4 py-8" id="admin-hq-wrapper">
      {/* Dynamic Upper Panel */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-8 pb-5 border-b border-white/5 gap-4">
        <div>
          <div className="flex items-center space-x-1 font-mono text-[9px] text-[#fbbf24] font-bold tracking-widest uppercase mb-1">
            <Terminal className="w-3.5 h-3.5 text-amber-500" />
            <span>CRXSHIL HQ TERMINAL // ROOT ACCESS</span>
          </div>
          <h1 className="font-display font-extrabold text-2xl text-white uppercase tracking-tight">
            Control Dashboard
          </h1>
        </div>

        {/* Dashboard Control Toggle Tabs */}
        <div className="flex space-x-2">
          <button
            onClick={() => setActiveTab("resources")}
            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-mono select-none transition-all ${
              activeTab === "resources"
                ? "bg-yellow-500/10 border border-yellow-500/30 text-yellow-400 font-semibold"
                : "bg-black/30 border border-white/5 text-zinc-500 hover:text-white"
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>RESOURCES</span>
          </button>
          
          <button
            onClick={() => setActiveTab("waitlist")}
            className={`flex items-center space-x-1.5 px-3 py-1.5 rounded-lg text-xs font-mono select-none transition-all ${
              activeTab === "waitlist"
                ? "bg-amber-500/10 border border-amber-500/30 text-amber-500 font-semibold"
                : "bg-black/30 border border-white/5 text-zinc-500 hover:text-white"
            }`}
          >
            <Users className="w-3.5 h-3.5" />
            <span>WAITLIST ({waitlist.length})</span>
          </button>

          <button
            onClick={onBack}
            className="flex items-center space-x-1 px-3 py-1.5 bg-zinc-900 border border-white/5 hover:bg-zinc-800 text-zinc-400 hover:text-white rounded-lg text-xs font-mono"
          >
            <ChevronLeft className="w-3.5 h-3.5" />
            <span>EXIT</span>
          </button>

          {onLogout && (
            <button
              onClick={onLogout}
              className="flex items-center space-x-1 px-3 py-1.5 bg-red-950/20 border border-red-500/20 hover:bg-red-950/45 text-red-400 hover:text-red-300 rounded-lg text-xs font-mono font-medium"
            >
              <span>LOG OUT</span>
            </button>
          )}
        </div>
      </div>

      {activeTab === "resources" ? (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Column A: Create / Edit Form */}
          <div className="lg:col-span-7 glass-panel rounded-2xl border-white/5 bg-zinc-950/40 p-6 relative">
            <div className="flex items-center justify-between mb-6 pb-2 border-b border-white/5">
              <h3 className="font-display font-bold text-sm text-white uppercase tracking-wider flex items-center">
                <PlusCircle className="w-4 h-4 text-yellow-400 mr-2" />
                <span>{isEditing ? "Edit Node" : "Publish New Strategy Node"}</span>
              </h3>
              {isEditing && (
                <button
                  type="button"
                  onClick={resetForm}
                  className="font-mono text-[9px] text-amber-500 uppercase font-bold hover:underline"
                >
                  Cancel Edit
                </button>
              )}
            </div>

            {/* Notification messages */}
            {successMsg && (
              <div className="mb-4 p-3 bg-yellow-950/20 border border-yellow-500/20 rounded-lg flex items-center text-yellow-400 text-xs font-mono">
                <Check className="w-4 h-4 mr-2" />
                <span>{successMsg}</span>
              </div>
            )}
            {errorMsg && (
              <div className="mb-4 p-3 bg-red-950/20 border border-red-500/20 rounded-lg flex items-center text-red-400 text-xs font-mono">
                <AlertCircle className="w-4 h-4 mr-2" />
                <span>{errorMsg}</span>
              </div>
            )}

            <form onSubmit={handleCreateOrUpdate} className="space-y-4 text-left">
              
              {/* Row 1: Title & Slug */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="flex flex-col space-y-1">
                  <label className="font-mono text-[9px] uppercase tracking-wider text-zinc-500">Resource Title</label>
                  <input
                    type="text"
                    required
                    value={title}
                    onChange={(e) => handleTitleChange(e.target.value)}
                    placeholder="e.g. Sales Playbook Volume 1"
                    className="w-full bg-black/60 border border-white/5 focus:border-yellow-500/50 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none placeholder-zinc-700 font-mono"
                  />
                </div>

                <div className="flex flex-col space-y-1">
                  <label className="font-mono text-[9px] uppercase tracking-wider text-zinc-500">Auto Generated URL Slug</label>
                  <input
                    type="text"
                    required
                    value={slug}
                    onChange={(e) => setSlug(e.target.value.toLowerCase().replace(/\s+/g, "-"))}
                    placeholder="e.g. sales-playbook-vol-1"
                    className="w-full bg-black/40 border border-white/5 focus:border-yellow-500/50 rounded-lg px-3 py-1.5 text-xs text-zinc-400 focus:outline-none font-mono"
                  />
                </div>
              </div>

              {/* Row 2: Category & Read Time */}
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="flex flex-col space-y-1">
                  <label className="font-mono text-[9px] uppercase tracking-wider text-zinc-500">Operational Category</label>
                  <select
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="w-full bg-black/60 border border-white/5 focus:border-yellow-500/50 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none font-mono"
                  >
                    <option value="Sales">Sales</option>
                    <option value="Business">Business</option>
                    <option value="Growth">Growth</option>
                    <option value="Building">Building</option>
                    <option value="Creating">Creating</option>
                  </select>
                </div>

                <div className="flex flex-col space-y-1">
                  <label className="font-mono text-[9px] uppercase tracking-wider text-zinc-500">Read Cost / Duration</label>
                  <input
                    type="text"
                    required
                    value={readTime}
                    onChange={(e) => setReadTime(e.target.value)}
                    placeholder="e.g. 5 min read"
                    className="w-full bg-black/60 border border-white/5 focus:border-yellow-500/50 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none placeholder-zinc-700 font-mono"
                  />
                </div>
              </div>

              {/* Cover image string selection and options */}
              <div className="flex flex-col space-y-1.5">
                <label className="font-mono text-[9px] uppercase tracking-wider text-zinc-500">Asset Cover Image URL</label>
                <input
                  type="url"
                  required
                  value={coverImage}
                  onChange={(e) => setCoverImage(e.target.value)}
                  placeholder="https://images.unsplash.com/..."
                  className="w-full bg-black/60 border border-white/5 focus:border-yellow-500/50 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none placeholder-zinc-700 font-mono"
                />
                
                {/* Visual grid select */}
                <span className="font-mono text-[8px] text-zinc-650 uppercase">Or select default premium artwork canvas:</span>
                <div className="flex space-x-2 pt-1 overflow-x-auto pb-1">
                  {premiumCovers.map((cov, idx) => (
                    <img
                      key={idx}
                      src={cov}
                      alt="Choice"
                      onClick={() => setCoverImage(cov)}
                      className={`w-12 h-8 object-cover rounded cursor-pointer border hover:border-yellow-400 transition-colors ${
                        coverImage === cov ? "border-yellow-500 scale-102 ring-1 ring-yellow-500" : "border-transparent"
                      }`}
                      referrerPolicy="no-referrer"
                    />
                  ))}
                </div>
              </div>

              {/* Brief Excerpt */}
              <div className="flex flex-col space-y-1">
                <label className="font-mono text-[9px] uppercase tracking-wider text-zinc-500">Overview / Excerpt (Card text)</label>
                <textarea
                  required
                  value={excerpt}
                  onChange={(e) => setExcerpt(e.target.value)}
                  placeholder="Insert 1-2 sentence high-level excerpt summarizing the primary payoff of the strategy node."
                  rows={2}
                  className="w-full bg-black/60 border border-white/5 focus:border-yellow-500/50 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none placeholder-zinc-700 font-sans"
                />
              </div>

              {/* Rich strategy content area */}
              <div className="flex flex-col space-y-1">
                <div className="flex justify-between items-center">
                  <label className="font-mono text-[9px] uppercase tracking-wider text-zinc-500">Markdown Strategy Content (Full article)</label>
                  <span className="font-mono text-[8px] text-zinc-650 uppercase">SUGGESTION: use ## titles & * lists</span>
                </div>
                <textarea
                  required
                  value={content}
                  onChange={(e) => setContent(e.target.value)}
                  placeholder="## Heading Title&#10;&#10;Use clean text style to design custom workflows, scripts or frameworks..."
                  rows={8}
                  className="w-full bg-black/60 border border-white/5 focus:border-yellow-500/50 rounded-lg p-3 text-xs text-zinc-300 focus:outline-none placeholder-zinc-700 font-mono leading-relaxed"
                />
              </div>

              {/* Published switch state toggle */}
              <div className="flex items-center justify-between py-2 border-t border-b border-white/5">
                <div className="flex flex-col text-left">
                  <span className="font-mono text-[10px] text-white uppercase font-bold">Publish Node Status</span>
                  <span className="font-mono text-[8px] text-zinc-500 uppercase">Nodes immediately resolve visually on homepage</span>
                </div>
                <button
                  type="button"
                  onClick={() => setPublished(!published)}
                  className="text-zinc-400 hover:text-white transition-colors"
                >
                  {published ? (
                    <div className="flex items-center text-yellow-400 space-x-1 text-xs font-mono font-bold">
                      <ToggleRight className="w-5 h-5" />
                      <span>LIVE ON NET</span>
                    </div>
                  ) : (
                    <div className="flex items-center text-zinc-600 space-x-1 text-xs font-mono font-bold">
                      <ToggleLeft className="w-5 h-5" />
                      <span>RESTRICTED DRAFT</span>
                    </div>
                  )}
                </button>
              </div>

              {/* Submitting controls */}
              <button
                type="submit"
                disabled={isLoading}
                className="w-full flex items-center justify-center space-x-2 py-2 border border-yellow-500/30 hover:border-yellow-500/60 bg-yellow-500/10 hover:bg-yellow-500/20 text-yellow-400 font-display font-bold text-xs uppercase tracking-wider rounded-lg transition-all duration-300 disabled:opacity-40"
              >
                {isLoading ? (
                  <Loader className="w-4 h-4 animate-spin text-yellow-500" />
                ) : (
                  <span>{isEditing ? "SAVE UPDATES" : "DEPLOY NODE TO DIGITAL HEADQUARTERS"}</span>
                )}
              </button>
            </form>
          </div>

          {/* Column B: Active strategies list */}
          <div className="lg:col-span-5 flex flex-col space-y-4">
            <div className="glass-panel rounded-2xl border-white/5 bg-zinc-950/40 p-4">
              <h4 className="font-display font-bold text-xs text-white uppercase tracking-wider mb-4 flex items-center">
                <FileText className="w-3.5 h-3.5 text-amber-500 mr-2" />
                <span>Active Assets ({resources.length})</span>
              </h4>

              <div className="space-y-2.5 max-h-[600px] overflow-y-auto pr-1">
                {resources.map((res) => (
                  <div
                    key={res.id}
                    className="flex items-start justify-between p-3 rounded-lg border border-white/5 bg-black/40 hover:border-zinc-800 transition-all"
                  >
                    <div className="text-left">
                      <h5 className="font-display font-bold text-xs text-zinc-200 line-clamp-1">{res.title}</h5>
                      <div className="flex items-center space-x-2 mt-1">
                        <span className="font-mono text-[8px] px-1.5 py-0.2 select-none border border-zinc-850 rounded bg-zinc-950 text-zinc-500 uppercase tracking-wider">
                          {res.category}
                        </span>
                        <span className={`font-mono text-[8px] font-bold ${res.published ? 'text-yellow-400' : 'text-zinc-650'}`}>
                          {res.published ? "● LIVE" : "● DRAFT"}
                        </span>
                      </div>
                    </div>

                    {/* Operational controls */}
                    <div className="flex items-center space-x-1 shrink-0">
                      <button
                        onClick={() => handleEditClick(res)}
                        className="p-1 rounded bg-zinc-950 hover:bg-zinc-900 border border-white/5 text-zinc-400 hover:text-white transition-all"
                        title="Edit Node Assets"
                      >
                        <Edit3 className="w-3 h-3" />
                      </button>
                      <button
                        onClick={() => handleDeleteClick(res.id)}
                        className="p-1 rounded bg-zinc-950 hover:bg-red-950/10 border border-white/5 text-zinc-455 hover:text-red-400 transition-all"
                        title="Delete permanently"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>

        </div>
      ) : (
        /* Waitlist Tab display representing admin-only registration & queue management */
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          
          {/* Column A: Secure Registration Form */}
          <div className="lg:col-span-4 glass-panel rounded-2xl border-white/5 bg-zinc-950/40 p-6 text-left">
            <h3 className="font-display font-bold text-xs text-white uppercase tracking-wider mb-4 pb-2 border-b border-white/5">
              Secure Registrations
            </h3>

            {regSuccess && (
              <div className="mb-4 p-3 bg-yellow-950/20 border border-yellow-500/20 rounded-lg flex items-center text-yellow-400 text-xs font-mono">
                <Check className="w-4 h-4 mr-2 shrink-0 text-yellow-400" />
                <span>{regSuccess}</span>
              </div>
            )}

            {regError && (
              <div className="mb-4 p-3 bg-red-950/20 border border-red-500/20 rounded-lg flex items-center text-red-400 text-xs font-mono">
                <AlertCircle className="w-4 h-4 mr-2 shrink-0 text-red-450" />
                <span>{regError}</span>
              </div>
            )}

            <form onSubmit={handleAdminRegister} className="space-y-4">
              <div className="flex flex-col space-y-1">
                <label className="font-mono text-[9px] uppercase tracking-wider text-zinc-500 font-semibold">Full Name</label>
                <input
                  type="text"
                  required
                  value={regName}
                  onChange={(e) => setRegName(e.target.value)}
                  placeholder="e.g. VIcky Koshal"
                  className="w-full bg-black/60 border border-white/5 focus:border-amber-500/50 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none placeholder-zinc-700 font-mono transition-colors"
                />
              </div>

              <div className="flex flex-col space-y-1">
                <label className="font-mono text-[9px] uppercase tracking-wider text-zinc-500 font-semibold">Email Address</label>
                <input
                  type="email"
                  required
                  value={regEmail}
                  onChange={(e) => setRegEmail(e.target.value)}
                  placeholder="e.g. email@domain.com"
                  className="w-full bg-black/60 border border-white/5 focus:border-amber-500/50 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none placeholder-zinc-700 font-mono transition-colors"
                />
              </div>

              <div className="flex flex-col space-y-1">
                <label className="font-mono text-[9px] uppercase tracking-wider text-zinc-500 font-semibold">Phone Contact Number</label>
                <input
                  type="tel"
                  required
                  value={regPhone}
                  onChange={(e) => setRegPhone(e.target.value)}
                  placeholder="e.g. +91 9876543212"
                  className="w-full bg-black/60 border border-white/5 focus:border-amber-500/50 rounded-lg px-3 py-1.5 text-xs text-white focus:outline-none placeholder-zinc-700 font-mono transition-colors"
                />
              </div>

              <button
                type="submit"
                disabled={isRegistering}
                className="w-full py-2.5 bg-amber-500/10 hover:bg-amber-500/20 border border-amber-500/30 text-amber-500 font-display font-bold text-xs uppercase tracking-wider rounded-lg transition-all duration-200"
              >
                {isRegistering ? "Registering Lead..." : "Register Community Lead"}
              </button>
            </form>
          </div>

          {/* Column B: Registrants List Display */}
          <div className="lg:col-span-8 glass-panel rounded-2xl border-white/5 bg-zinc-950/40 p-6">
            <div className="flex items-center justify-between mb-6 pb-2 border-b border-white/5">
              <h3 className="font-display font-bold text-xs text-white uppercase tracking-wider flex items-center">
                <Users className="w-4 h-4 text-amber-500 mr-2" />
                <span>Waitlisted Sequences</span>
              </h3>
              <span className="font-mono text-[10px] text-zinc-500 font-semibold">
                {waitlist.length} Registrants
              </span>
            </div>

            {waitlist.length === 0 ? (
              <div className="py-12 text-center">
                <Mail className="w-10 h-10 text-zinc-650 mx-auto mb-3" />
                <p className="font-mono text-xs text-zinc-500">NO EMAILS REGISTERED YET</p>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {waitlist.map((entry) => (
                  <div
                    key={entry.id}
                    className="p-3.5 rounded-xl border border-white/5 bg-black/40 text-left flex flex-col justify-between space-y-2 hover:border-zinc-800 transition-all"
                  >
                    <div>
                      {entry.fullName && (
                        <div className="mb-1">
                          <span className="font-mono text-[8px] text-zinc-500 uppercase tracking-widest block leading-none">Member Name</span>
                          <span className="font-sans text-xs text-zinc-200 font-bold">{entry.fullName}</span>
                        </div>
                      )}
                      <div className="mb-1">
                        <span className="font-mono text-[8px] text-zinc-500 uppercase tracking-widest block leading-none">Email Address</span>
                        <span className="font-mono text-xs text-yellow-400 select-all truncate block">{entry.email}</span>
                      </div>
                      <div>
                        <span className="font-mono text-[8px] text-zinc-500 uppercase tracking-widest block leading-none">Phone Contact</span>
                        <span className="font-mono text-xs text-amber-500 font-bold select-all block">{entry.phone || "No phone number saved"}</span>
                      </div>
                    </div>
                    <div className="flex items-center justify-between mt-3 pt-2.5 border-t border-white/5">
                      <span className="font-mono text-[8px] text-zinc-650 font-semibold">DATE REGISTERED:</span>
                      <span className="font-mono text-[8px] text-zinc-500 font-semibold">
                        {new Date(entry.createdAt).toLocaleString()}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </div>

        </div>
      )}
    </div>
  );
}
