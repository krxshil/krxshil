/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { ArrowLeft, BookOpen, Clock, Calendar, Sparkles, Terminal, Share2, CornerDownRight } from "lucide-react";
import { motion } from "motion/react";
import { Resource } from "../types";

interface ResourceViewProps {
  resource: Resource;
  onBack: () => void;
}

export default function ResourceView({ resource, onBack }: ResourceViewProps) {
  // Render clean styled rows from pseudo-markdown strings
  const renderContent = (text: string) => {
    const lines = text.split("\n");
    let inCodeBlock = false;
    let codeContent: string[] = [];

    const elements: React.ReactNode[] = [];

    lines.forEach((line, index) => {
      // Handle code block boundaries
      if (line.trim().startsWith("```")) {
        if (inCodeBlock) {
          // Close block and render code panel
          inCodeBlock = false;
          elements.push(
            <div key={`code-${index}`} className="my-6 rounded-xl border border-white/5 bg-zinc-950 p-4 font-mono text-[11px] text-yellow-400 overflow-x-auto relative shadow-2xl">
              <div className="absolute top-2.5 right-3 flex items-center space-x-1.5">
                <div className="w-1.5 h-1.5 rounded-full bg-red-500/60" />
                <div className="w-1.5 h-1.5 rounded-full bg-amber-500/60" />
                <div className="w-1.5 h-1.5 rounded-full bg-yellow-500/60" />
              </div>
              <pre className="text-zinc-300 select-all leading-normal whitespace-pre">
                {codeContent.join("\n")}
              </pre>
            </div>
          );
          codeContent = [];
        } else {
          inCodeBlock = true;
        }
        return;
      }

      // If in code block, accumulate
      if (inCodeBlock) {
        codeContent.push(line);
        return;
      }

      // Headings
      if (line.trim().startsWith("## ")) {
        elements.push(
          <h2 key={`h2-${index}`} className="font-display font-bold text-xl text-white uppercase tracking-tight mt-8 mb-4 border-b border-white/5 pb-2 glow-text-yellow">
            {line.replace("## ", "")}
          </h2>
        );
        return;
      }
      if (line.trim().startsWith("### ")) {
        elements.push(
          <h3 key={`h3-${index}`} className="font-display font-semibold text-base text-amber-400 uppercase tracking-wide mt-6 mb-3">
            {line.replace("### ", "")}
          </h3>
        );
        return;
      }

      // Blockquote
      if (line.trim().startsWith("> ")) {
        elements.push(
          <div key={`quote-${index}`} className="my-6 pl-4 border-l-2 border-yellow-500 py-1 bg-yellow-950/5 rounded-r-lg font-sans text-xs italic text-zinc-300 uppercase leading-relaxed tracking-wide">
            {line.replace("> ", "").replace(/"/g, "")}
          </div>
        );
        return;
      }

      // List Items
      if (line.trim().startsWith("* ") || line.trim().startsWith("- ")) {
        const cleanItem = line.trim().substring(2);
        // Stylize bold strings inside lists
        const parts = cleanItem.split("**");
        elements.push(
          <div key={`li-${index}`} className="flex items-start space-x-2 my-2.5 pl-2">
            <CornerDownRight className="w-3.5 h-3.5 text-yellow-500 shrink-0 mt-0.5" />
            <p className="font-sans text-xs text-zinc-400 leading-relaxed font-light">
              {parts.map((p, pIdx) => (pIdx % 2 === 1 ? <strong key={pIdx} className="font-semibold text-white">{p}</strong> : p))}
            </p>
          </div>
        );
        return;
      }

      // Sub-bullet indent listings
      if (line.trim().match(/^\d+\.\s+\*\*/) || line.trim().match(/^\d+\.\s+/)) {
        const cleanNumItem = line.replace(/^\d+\.\s+/, "");
        const partsNum = cleanNumItem.split("**");
        elements.push(
          <div key={`num-${index}`} className="flex items-start space-x-2 my-2.5 pl-4">
            <span className="font-mono text-[10px] text-amber-500 shrink-0 mt-0.5">↳</span>
            <p className="font-sans text-xs text-zinc-400 leading-relaxed font-light">
              {partsNum.map((p, pIdx) => (pIdx % 2 === 1 ? <strong key={pIdx} className="font-semibold text-amber-450">{p}</strong> : p))}
            </p>
          </div>
        );
        return;
      }

      // Empty Lines
      if (!line.trim()) {
        return;
      }

      // Standard Paragraph lines
      const partsP = line.split("**");
      elements.push(
        <p key={`p-${index}`} className="font-sans text-xs text-zinc-400 font-light leading-relaxed my-3.5">
          {partsP.map((textStr, tIdx) => {
            const hasInlineCode = textStr.includes("`");
            if (hasInlineCode) {
              const codeParts = textStr.split("`");
              return codeParts.map((subPart, sIdx) => 
                sIdx % 2 === 1 
                  ? <code key={sIdx} className="px-1.5 py-0.5 mx-0.5 rounded bg-zinc-900 border border-white/5 font-mono text-[10px] text-amber-400 font-bold">{subPart}</code>
                  : subPart
              );
            }
            return tIdx % 2 === 1 ? <strong key={tIdx} className="font-semibold text-white">{textStr}</strong> : textStr;
          })}
        </p>
      );
    });

    return elements;
  };

  return (
    <div className="max-w-3xl mx-auto px-4 py-8" id="strategy-reader-container">
      {/* Upper Navigation Row */}
      <div className="flex items-center justify-between mb-8 pb-4 border-b border-white/5">
        <button
          onClick={onBack}
          className="flex items-center space-x-1.5 px-3 py-1.5 text-xs font-mono text-zinc-400 hover:text-white transition-colors"
        >
          <ArrowLeft className="w-3.5 h-3.5 text-yellow-400" />
          <span>BACK TO PLATFORM</span>
        </button>

        <div className="flex items-center space-x-2">
          {/* Simulation lock signifier */}
          <span className="font-mono text-[9px] text-yellow-400 border border-yellow-500/20 bg-yellow-950/20 px-2.5 py-0.5 rounded-full font-bold uppercase tracking-widest">
            Licensed Node // dec-r01
          </span>
        </div>
      </div>

      {/* Elegant Header section */}
      <div className="mb-8">
        <div className="flex items-center space-x-2 text-amber-400 font-mono text-[10px] font-semibold tracking-widest uppercase mb-2">
          <BookOpen className="w-3.5 h-3.5" />
          <span>{resource.category} STRATEGY PORTFOLIO</span>
        </div>
        
        <h1 className="font-display font-extrabold text-2xl sm:text-3xl text-white uppercase leading-tight mb-4">
          {resource.title}
        </h1>

        {/* Informative details horizontal band */}
        <div className="flex flex-wrap gap-x-6 gap-y-2 text-xs font-mono text-zinc-500 pt-4 border-t border-white/5">
          <div className="flex items-center">
            <Clock className="w-3.5 h-3.5 mr-1.5 text-yellow-500" />
            <span>Allocation: {resource.readTime}</span>
          </div>
          <div className="flex items-center">
            <Calendar className="w-3.5 h-3.5 mr-1.5 text-amber-500" />
            <span>Created: {new Date(resource.createdAt).toLocaleDateString()}</span>
          </div>
          <div className="flex items-center">
            <Terminal className="w-3.5 h-3.5 mr-1.5 text-yellow-500" />
            <span>Author: Krishil Joshi</span>
          </div>
        </div>
      </div>

      {/* Big widescreen cover banner */}
      <div className="relative aspect-video w-full rounded-2xl overflow-hidden glass-panel border-white/5 mb-8">
        <div className="absolute inset-0 bg-gradient-to-t from-[#050505] to-transparent z-10 opacity-60" />
        <img
          src={resource.coverImage || "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&q=80&w=811"}
          alt={resource.title}
          className="w-full h-full object-cover"
          referrerPolicy="no-referrer"
        />
      </div>

      {/* Styled text layout */}
      <article className="glass-panel rounded-2xl p-6 sm:p-8 border-white/5 bg-zinc-950/40 relative shadow-2xl mb-12">
        <div className="absolute -top-10 -right-10 w-24 h-24 bg-yellow-500/5 rounded-full filter blur-xl pointer-events-none" />
        
        {/* Dynamic Styled Output */}
        <div className="prose prose-invert max-w-none">
          {renderContent(resource.content)}
        </div>
      </article>

      {/* Quick visual footer CTA to instagram */}
      <div className="pt-8 border-t border-white/5 text-center flex flex-col items-center justify-center space-y-4">
        <span className="font-mono text-[9px] text-zinc-500 uppercase tracking-widest font-bold">
          FOUND VALUE IN THIS FRAMEWORK BRIEF?
        </span>
        <a
          href="https://instagram.com/krxshil"
          target="_blank"
          rel="noreferrer"
          className="inline-flex items-center space-x-2 px-5 py-2 hover:border-amber-500/30 border border-white/5 rounded-xl text-zinc-300 hover:text-amber-400 font-mono text-xs tracking-wider transition-all duration-300"
        >
          <Share2 className="w-3.5 h-3.5" />
          <span>EXPRESS INTEL WITH @KRXSHIL</span>
        </a>
      </div>
    </div>
  );
}
