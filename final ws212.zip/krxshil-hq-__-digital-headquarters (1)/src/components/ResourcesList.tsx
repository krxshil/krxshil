/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { Book, Grid, SlidersHorizontal, Sparkles, Filter } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import { Resource } from "../types";
import ResourceCard from "./ResourceCard";

interface ResourcesListProps {
  resources: Resource[];
  isLoading: boolean;
  selectedCategory: string;
  setSelectedCategory: (category: string) => void;
  onResourceSelect: (slug: string) => void;
  onEnterAuth: () => void;
  isAuthenticated: boolean;
}

export default function ResourcesList({
  resources,
  isLoading,
  selectedCategory,
  setSelectedCategory,
  onResourceSelect,
  onEnterAuth,
  isAuthenticated,
}: ResourcesListProps) {
  const categories = ["All", "Sales", "Business", "Growth", "Building", "Creating"];

  const filteredResources = selectedCategory === "All"
    ? resources
    : resources.filter((r) => r.category === selectedCategory);

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.08,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 15 },
    visible: { opacity: 1, y: 0, transition: { duration: 0.5, ease: "easeOut" } },
  };

  return (
    <div className="w-full" id="resources-grid-wrapper">
      {/* Category Selection Filter Track */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-8 pb-5 border-b border-white/5 gap-4">
        <div>
          <div className="flex items-center space-x-2 text-yellow-400 font-mono text-xs font-semibold tracking-widest uppercase mb-1">
            <Sparkles className="w-3.5 h-3.5 animate-spin" style={{ animationDuration: "3s" }} />
            <span>Curated Knowledge Bases</span>
          </div>
          <h2 className="font-display font-bold text-2xl text-white tracking-tight uppercase">
            ALL THE SAUCE
          </h2>
        </div>

        {/* Filter Badges */}
        <div className="flex flex-wrap gap-1.5 glass-panel p-1 rounded-xl border-white/5 bg-black/40">
          {categories.map((cat) => {
            const isActive = selectedCategory === cat;
            return (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-3 py-1.5 text-[10px] font-mono tracking-wider font-semibold rounded-lg uppercase select-none transition-all duration-200 ${
                  isActive
                    ? "bg-yellow-400 text-black shadow-[0_0_12px_rgba(234,179,8,0.5)]"
                    : "text-zinc-450 hover:text-white hover:bg-white/5"
                }`}
              >
                {cat}
              </button>
            );
          })}
        </div>
      </div>

      {/* Grid Display */}
      {isLoading ? (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          {[1, 2, 3].map((n) => (
            <div key={n} className="h-72 rounded-xl glass-panel animate-pulse flex items-center justify-center border-white/5">
              <div className="text-zinc-650 font-mono text-[10px] uppercase animate-ping">Syncing Hub...</div>
            </div>
          ))}
        </div>
      ) : filteredResources.length === 0 ? (
        <div className="flex flex-col items-center justify-center py-20 text-center glass-panel rounded-2xl border-white/5 p-6">
          <Book className="w-8 h-8 text-amber-500/50 mb-4 animate-bounce" />
          <h3 className="font-display font-semibold text-lg text-white uppercase mb-1">Database Cleared</h3>
          <p className="font-sans text-xs text-zinc-500 max-w-xs leading-relaxed font-light">
            No strategies registered under this filter yet. Create new nodes in the Terminal control room.
          </p>
        </div>
      ) : (
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          {filteredResources.map((res) => (
            <motion.div key={res.id} variants={itemVariants}>
              <ResourceCard
                resource={res}
                onClick={(slug) => {
                  onResourceSelect(slug);
                }}
              />
            </motion.div>
          ))}
        </motion.div>
      )}
    </div>
  );
}
