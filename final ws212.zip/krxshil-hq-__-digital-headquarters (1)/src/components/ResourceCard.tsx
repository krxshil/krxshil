/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React from "react";
import { BookOpen, Clock, ArrowUpRight } from "lucide-react";
import { motion } from "motion/react";
import { Resource } from "../types";

interface ResourceCardProps {
  resource: Resource;
  onClick: (slug: string) => void;
}

export default function ResourceCard({ resource, onClick }: ResourceCardProps) {
  // Category coloring mapping
  const categoryStyles: Record<string, string> = {
    Sales: "border-yellow-500/30 text-yellow-400 bg-yellow-950/20",
    Business: "border-amber-500/30 text-amber-400 bg-amber-950/20",
    Growth: "border-yellow-500/30 text-yellow-400 bg-yellow-950/20",
    Building: "border-amber-500/30 text-amber-400 bg-amber-950/20",
    Creating: "border-yellow-500/30 text-yellow-400 bg-yellow-950/20",
  };

  const currentStyles = categoryStyles[resource.category] || "border-zinc-800 text-zinc-400 bg-zinc-950/20";

  return (
    <motion.div
      whileHover={{ y: -6, scale: 1.01 }}
      transition={{ duration: 0.3, ease: "easeOut" }}
      onClick={() => onClick(resource.slug)}
      className="relative flex flex-col h-full rounded-xl glass-panel border-white/5 cursor-pointer overflow-hidden group shadow-lg"
    >
      {/* Visual background gradient glow on hover */}
      <div className="absolute inset-0 bg-gradient-to-t from-yellow-950/10 via-black/30 to-black/90 z-0 group-hover:from-yellow-950/20 transition-all duration-300" />
      
      {/* Image Container with zoom blur */}
      <div className="relative aspect-video w-full overflow-hidden border-b border-white/5 z-10">
        <div className="absolute inset-0 bg-black/40 z-10 group-hover:bg-black/20 transition-all duration-300" />
        <img
          src={resource.coverImage || "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&q=80&w=800"}
          alt={resource.title}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500 ease-out"
          referrerPolicy="no-referrer"
        />
        {/* Float action tag */}
        <div className="absolute top-3 right-3 z-20 flex items-center justify-center w-7 h-7 rounded-lg bg-black/70 border border-white/10 text-white opacity-0 group-hover:opacity-100 group-hover:translate-x-0 translate-x-2 transition-all duration-300">
          <ArrowUpRight className="w-4 h-4 text-yellow-400" />
        </div>
      </div>

      {/* Meta Content area */}
      <div className="relative flex flex-col flex-grow p-5 z-10">
        {/* Category & Time Row */}
        <div className="flex items-center justify-between mb-3.5">
          <span className={`px-2.5 py-0.5 border rounded-full text-[9px] font-mono uppercase tracking-widest font-semibold ${currentStyles}`}>
            {resource.category}
          </span>
          <div className="flex items-center text-zinc-500 text-[10px] font-mono">
            <Clock className="w-3 h-3 mr-1 text-yellow-500" />
            <span>{resource.readTime}</span>
          </div>
        </div>

        {/* Resource Title */}
        <h3 className="font-display font-semibold text-base text-white group-hover:text-yellow-400 leading-snug tracking-tight mb-2 transition-colors duration-200">
          {resource.title}
        </h3>

        {/* Short description */}
        <p className="font-sans text-xs text-zinc-400 font-light leading-relaxed mb-4 line-clamp-2">
          {resource.excerpt}
        </p>

        {/* Decorative accent footer line */}
        <div className="mt-auto pt-4 border-t border-white/5 flex items-center justify-between">
          <span className="font-mono text-[9px] text-zinc-600 group-hover:text-amber-500/70 transition-colors uppercase font-bold tracking-wider">
            HQ // STRATEGY ACCESS
          </span>
          <span className="font-display text-xs text-yellow-400 opacity-60 group-hover:opacity-100 group-hover:translate-x-1 transition-all flex items-center font-bold">
            Unravel Code
          </span>
        </div>
      </div>
    </motion.div>
  );
}
