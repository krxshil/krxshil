/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

export interface Resource {
  id: string;
  slug: string;
  title: string;
  category: "Sales" | "Business" | "Growth" | "Building" | "Creating";
  readTime: string;
  excerpt: string;
  content: string; // Markdown or rich HTML text
  coverImage: string; // Dynamic URL or base64
  published: boolean;
  createdAt: string;
}

export interface User {
  id: string;
  email: string;
  isAdmin: boolean;
  fullName?: string;
  avatarUrl?: string;
}

export interface WaitlistEntry {
  id: string;
  email: string;
  phone: string;
  fullName?: string;
  createdAt: string;
}

export interface AuthResponse {
  user: User | null;
  error?: string;
  token?: string;
}
