/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { Resource } from "../types";

export const defaultResources: Resource[] = [
  {
    id: "res-1",
    slug: "cold-dm-framework",
    title: "The Gen-Z Cold DM Framework for Closing High-Ticket Clients",
    category: "Sales",
    readTime: "4 min read",
    excerpt: "The exact direct outreach script and psychological model used to capture attention from 7-figure founders within 4 seconds.",
    content: `## The Modern Rules of Attention

The average attention span of a 7-figure founder is currently under 4 seconds. If your cold outreach begins with *"Hey, hope you're having a good week..."* or *"My name is..."*, you have already lost. 

To land high-ticket retainer contracts, your DMs must be highly personalized, action-oriented, and ruthlessly concise. Here is the exact friction-free structure Krishil Joshi uses to generate high-value responses.

---

### Step 1: The Personalized Hook (De-commoditize)
Start with a highly specific trigger showing you actually understand their business. Never compliment generalities. Reference a specific video, campaign, or product update.

*   ❌ **Bad:** "Hey, love your content! You are doing an amazing job."
*   ✅ **Good:** "Saw your breakdown on how you scaled MRR through YouTube Shorts. Dynamic editing was clean, but noticed the description links were un-optimized."

### Step 2: The Direct Gap Identification (Pain Point)
Immediately point out a bottleneck in their workflow. Do not offer to fix it yet—simply frame the problem clearly so they feel the loss.

> "Right now, your leads have to click through three pages just to book a call. You're likely losing 30-40% of warm traffic at the sign-up bottleneck."

### Step 3: The Case Study / Quick Proof (Authority)
Provide a 1-sentence social proof or direct value proof. If you don't have client results yet, offer a specific custom asset built for them.

> "Built a custom 1-click booking flow for another scale-up that immediately lifted call bookings by 37% last month."

### Step 4: The Friction-Free Call to Action (The Low-Bar CTA)
Do NOT ask for a 30-minute meeting. Instead, ask for permission to send a 60-second video breakdown. This requires zero commitment from them.

*   ❌ **Bad:** "Can we hop on a quick 30-minute Zoom call this Tuesday at 2 PM?"
*   ✅ **Good:** "Mind if I send over a quick 60-second video showing how we did it? No pitch, just some quick value-add."

---

### The Cheat Sheet (Copy-Paste)
\`\`\`text
"Hey [Name], saw your latest product launch [Details]. 
Clean aesthetic, but noticed [Bottleneck].

We solved this for [Client] by executing [Strategy], 
which boosted secondary conversions by [Result].

Mind if I drop a 60s Loom showing how you can easily fix this? 
If not, no worries at all."
\`\`\`
`,
    coverImage: "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?q=80&w=800&auto=format&fit=crop",
    published: true,
    createdAt: "2026-05-15T08:00:00Z"
  },
  {
    id: "res-2",
    slug: "discovery-call-script",
    title: "High-Conversion Discovery Call Blueprint: From Greeting to Close",
    category: "Business",
    readTime: "5 min read",
    excerpt: "The master control framework built for qualifying prospects, exposing deep operational pain, and positioning yourself as the only solution.",
    content: `## The Psychology of the Call

A discovery call is NOT a pitch. It is an audit, a qualification, and a strategic diagnosis. The moment you start selling features or explaining your pricing too early, you lose authority. You should act like a premium consultant diagnosing an operational disease.

Here is the exact step-by-step discovery script designed to maintain pristine luxury framing.

---

### Part 1: Frame the Conversation (0 - 5 Mins)
Establish control immediately. Welcome them, confirm the timeline, and outline the exact roadmap for the call so they feel guided by a professional.

> "Hey [Name], great to connect. The goal of this call is simple. I want to dive into what you're building, see if my framework is a fit to unlock additional leverage, and if so, map out a growth blueprint. If not, I'll point you to the right resource. Sound fair?"

### Part 2: The Qualification Phase (5 - 15 Mins)
Ask high-value, open-ended questions that force them to reveal their exact pain points. Let them talk 80% of the time.

1.  **"What is the absolute number-one bottleneck holding you back from hitting your targets this quarter?"**
2.  **"What have you tried to solve this already, and why did it fail?"**
3.  **"If we don't fix this over the next 90 days, what does that cost the business structurally?"**

### Part 3: Quantify the Gap (15 - 20 Mins)
Connect their problem directly to a specific financial or operational leak. Make them calculate the numeric loss themselves.

> "So if you're missing out on 5 leads a week, with a customer lifetime value of $2,000... that's effectively $10,000 in monthly revenue slipping through the cracks right now. Is that accurate?"

### Part 4: Offer the Solution & Close (20 - 30 Mins)
Position your service as the custom bridge over their gap. Give them structural clarity.

> "Based on what you just shared, you don't need general consulting. You need a dedicated customer acquisition funnel to automate outreach. Here is exactly how we'll build it..."

---

### Pro-Tips for Krishil's Close
*   **The Power Silence:** After you state your pricing or proposal, shut up. The first person to speak carries the pressure.
*   **Assume Clean Authority:** Speak with calm conviction. Never sound desperate for the signature.
`,
    coverImage: "https://images.unsplash.com/photo-1639762681485-074b7f938ba0?q=80&w=800&auto=format&fit=crop",
    published: true,
    createdAt: "2026-05-20T10:00:00Z"
  },
  {
    id: "res-3",
    slug: "objection-handling",
    title: "The Ironclad Objection Handling Matrix: Firing Back on Overjections",
    category: "Growth",
    readTime: "4 min read",
    excerpt: "Stop letting objections ruin your close. Master these psychological overrides to address price, timeline, and authority blocks instantly.",
    content: `## Objections are Buying Signals

An objection is not a 'No'. It is a request for further conviction. When a client objects, they are asking you to resolve a hidden friction that prevents them from acting.

Below is the psychological framework Krishil uses to turn resistance into agreement.

---

### Objection 1: "It's too expensive."
Never defend your price. Defense implies your price is open for debate. Instead, pivot the conversation entirely from *cost* to *return-on-investment (ROI)*.

*   ❌ **Bad:** "We can give you a 10% discount if you sign today."
*   ✅ **Good:** "Our service costs $5,000. But we just mapped out that your current lead bottleneck is losing you $15,000 every single month. Relative to that $15,000 bleed, our solution is actually a net gain of $10,000. Do you want to continue losing $15k per month to save $5k once?"

### Objection 2: "I need to think about it / Send me an email."
Usually, this is a polite brush-off designed to escape the call. Flush out the real concern immediately.

> "Totally understand, [Name]. Usually, when someone says they need to think about it, it means either they don't see the value, they don't trust our delivery, or they find the investment too risky. Which one is it in our case?"

*This level of raw honesty builds massive trust and forces them to tell you the real issue.*

### Objection 3: "We're not ready / Bad timing."
Reframe the delay as an ongoing financial leak.

> "I appreciate your schedule is packed. But every week you delay represents another $3,000 lost to unoptimized conversion. Are you willing to pay a $12k penalty over the next month just to wait for the perfect timing?"

---

### The Golden Rule
Always maintain frame control. You are the expert. If they reject your methodology, be prepared to walk away. Truly premium builders do not chase clients.
`,
    coverImage: "https://images.unsplash.com/photo-1634017839464-5c339ebe3cb4?q=80&w=800&auto=format&fit=crop",
    published: true,
    createdAt: "2026-05-25T14:00:00Z"
  },
  {
    id: "res-4",
    slug: "sales-playbook",
    title: "The Zero to $10k/Month Blueprint: A Builder's Guide to Scale",
    category: "Building",
    readTime: "6 min read",
    excerpt: "The exact blueprint mapping acquisition channels, qualifying leads, and closing high-dollar deals consistently with zero fluff.",
    content: `## Structuring the Machine

Going from zero to $10,000 a month in recurring revenue isn't about working 80 hours a week. It is about building a scalable system of customer acquisition, high-impact branding, and standardized sales delivery.

Here is the exact structural model used by Gen-Z entrepreneurs to scale in the digital space.

---

### Phase 1: High-Ticket Offer Architecture
Do not sell low-price ebooks or tiny consulting sessions. Package your knowledge into a high-ticket, high-impact offering priced at a minimum of $2,000 - $5,000.

*   **Solve an intense, immediate pain point** (e.g., getting highly-qualified leads, building high-conversion funnels, or structuring raw video-editing assets for organic reach).
*   **Focus on complete-delivery systems**, not hourly consulting. Sell *outcomes*, not *hours*.

### Phase 2: Dual Outreach Engines
Set up two acquisition systems running concurrently to feed your pipeline:

1.  **Inbound Organic Authority (Instagram/X):** Share radical, actionable strategies that demonstrate your unmatched capability. Publish breaking insights, breakdown case studies, and visual proofs of your work.
2.  **Outbound Client Acquisition:** Reach out directly to 15-20 highly-qualified prospects every single day using our signature Cold DM Framework.

### Phase 3: The Conversion Flow
Your customer journey should be clean, low-friction, and exceptionally premium.

\`\`\`text
Social Media Authority
       ↓
Cold Outreach Response
       ↓
Value-Add Loom / Free Blueprint
       ↓
30-Min Discovery Audits
       ↓
Close / Clean Onboarding Link
\`\`\`

---

### Phase 4: Ruthless Automation
Document every single workflow. As soon as you scale past $5,000/month, hire a dedicated junior setter to handle outreach and initial qualification. Focus 100% of your energy on high-level strategy, closing deals, and scaling systems.
`,
    coverImage: "https://images.unsplash.com/photo-1635070041078-e363dbe005cb?q=80&w=800&auto=format&fit=crop",
    published: true,
    createdAt: "2026-05-28T16:30:00Z"
  }
];
