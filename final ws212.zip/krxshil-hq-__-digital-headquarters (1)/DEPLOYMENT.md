# 🪐 DEPLOYING KRXSHIL HQ TO PRODUCTION

This document outlines the direct checklist for hosting the personal brand digital headquarters for **Krishil Joshi (@krxshil)**. 

The website is engineered with a **Vite + Express React Full-Stack App** architecture, storing dynamic resources and waitlists. It is designed to be easily compatible with standard cloud servers or serverless environments (like Vercel or Google Cloud Run).

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 1. SWAPPING THE BACKEND TO SUPABASE

To migrate from the local JSON database file (`/data/database.json`) to your live **Supabase** instance, perform these two simple integrations:

### Step A: Apply the SQL Schema
1. Log in to your [Supabase Dashboard](https://supabase.com).
2. Create a new project named `krxshil-hq`.
3. Navigate to the **SQL Editor** in the left menu.
4. Copy the complete SQL commands inside `/supabase_schema.sql` of this project.
5. Paste them into the editor and click **Run**. This will create the `profiles`, `resources`, and `waitlist` tables with automated admin bindings and Row-Level Security!

### Step B: Hook up Environmental Variables
When deploying, supply these environment variables to inject your Supabase client endpoints:

```env
# Create these in Vercel or Cloud Run secrets panels
VITE_SUPABASE_URL="https://your-supabase-project-id.supabase.co"
VITE_SUPABASE_ANON_KEY="your-supabase-anonymous-api-key"
```

The database routes in your production code will listen to these variables and automatically switch from local JSON file writing to direct Postgres SQL insertions.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

## 2. DEPLOYMENT TARGETS

### Target Option A: Deploying on Vercel (Easiest)
Vercel is the premier platform for hosting modern frontend layouts.

1. Push your completed repository code to a private or public GitHub repo.
2. Go to the [Vercel Dashboard](https://vercel.com) and click **Add New Project**.
3. Import your repository.
4. In the **Build and Development Settings**:
   - Vercel automatically detects Vite configurations. Leave settings at default.
5. In **Environment Variables**, add:
   - `GEMINI_API_KEY` (if using advanced AI models)
   - `VITE_SUPABASE_URL` và `VITE_SUPABASE_ANON_KEY`.
6. Click **Deploy**. Vercel will build the static client-side bundle and host it instantly!

*Note: Since Vercel executes serverless front-ends by default, any Express API routes `/api/*` can be deployed as serverless functions in the `/api` directory or hosted on a tiny server container like Render or Railway.*

---

### Target Option B: Deploying on Cloud Run (Container Deployment)
To host the full-stack system intact in a single container:

1. Create a project in [Google Cloud Console](https://console.cloud.google.com).
2. Install the `gcloud` developer CLI.
3. Deploy the container directly from the root workspace using:
   ```bash
   gcloud run deploy krxshil-hq --source . --port 3000 --allow-unauthenticated --region us-central1
   ```
4. This command will:
   - Identify your package.json setup
   - Pack your dependencies and run `npm run build`
   - Boot up your compiled `node dist/server.cjs` backend
   - Allocate a secure, load-balanced green URL with free SSL certificates!
