-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
-- SUPABASE / POSTGRES DATABASE SCHEMA
-- FOR THE KRISHIL JOSHI (@KRXSHIL) DIGITAL HEADQUARTERS
-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
-- This file defines production SQL structures, Row-Level Security (RLS),
-- triggers, and functions to persist profiles, resources, and waitlist queues.
-- Run this script inside the SQL Editor of your Supabase Workspace.

-- Enable UUID generation extension
create extension if not exists "uuid-ossp";

-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
-- 1. PROFILES DATA TABLE (Syncs automatically with Auth users)
-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
create table public.profiles (
  id uuid references auth.users on delete cascade not null primary key,
  email text unique not null,
  full_name text,
  is_admin boolean default false not null,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- Enable Row-Level Security for Profiles
alter table public.profiles enable row level security;

-- Policies for public.profiles
create policy "Allow profile owners to view their own ID data"
  on public.profiles for select
  using (auth.uid() = id);

create policy "Allow profile owners to update their own entries"
  on public.profiles for update
  using (auth.uid() = id);

create policy "Admins have root access inside profile indices"
  on public.profiles for all
  using (
    exists (
      select 1 from public.profiles
      where id = auth.uid() and is_admin = true
    )
  );

-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
-- AUTOMATIC PROFILE SYNCRONIZATION TRIGGER
-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
-- Automatically creates a client entry in public.profiles when someone
-- registers on the signup screen via supabase auth.

create or replace function public.handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, email, full_name, is_admin)
  values (
    new.id,
    new.email,
    coalesce(new.raw_user_meta_data->>'full_name', split_part(new.email, '@', 1)),
    case 
      -- Assign admin credentials to owner's precise email profiles
      when new.email = 'krishhugamer@gmail.com' then true
      when new.email like 'krxshil%' then true
      else false
    end
  );
  return new;
end;
$$ language plpgsql security definer;

create or replace trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();


-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
-- 2. STRATEGIES & RESOURCES DATA TABLE
-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
create table public.resources (
  id uuid default uuid_generate_v4() primary key,
  slug text unique not null,
  title text not null,
  category text check (category in ('Sales', 'Business', 'Growth', 'Building', 'Creating')) not null,
  read_time text default '3 min read'::text,
  excerpt text,
  content text not null,
  cover_image text default 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&q=80&w=800'::text,
  published boolean default true not null,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- Create slug indexation for fast routes resolution
create index if on_resources_slug_idx on public.resources (slug);

-- Enable Row-Level Security for Resources
alter table public.resources enable row level security;

-- Policies for public.resources
create policy "Allow anyone to query published strategy nodes"
  on public.resources for select
  using (published = true);

create policy "Admins retain complete control over resources database"
  on public.resources for all
  using (
    exists (
      select 1 from public.profiles
      where id = auth.uid() and is_admin = true
    )
  );


-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
-- 3. SYNDICATE COMMUNITY WAITLIST DATA TABLE
-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
create table public.waitlist (
  id uuid default uuid_generate_v4() primary key,
  email text unique not null,
  created_at timestamp with time zone default timezone('utc'::text, now()) not null
);

-- Enable Row-Level Security for Waitlist
alter table public.waitlist enable row level security;

-- Policies for public.waitlist
create policy "Allow anyone to sign up to the community queue"
  on public.waitlist for insert
  with check (email like '%@%');

create policy "Admins are permitted to extract waitlist registrants"
  on public.waitlist for select
  using (
    exists (
      select 1 from public.profiles
      where id = auth.uid() and is_admin = true
    )
  );


-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
-- 4. PRELOAD INITIAL DATA EXAMPLES
-- ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
insert into public.resources (slug, title, category, read_time, excerpt, content, cover_image, published)
values 
(
  'cold-dm-framework',
  'The Gen-Z Cold DM Framework for Closing High-Ticket Clients',
  'Sales',
  '4 min read',
  'The exact direct outreach script and psychological model used to capture attention from 7-figure founders within 4 seconds.',
  '## The Modern Rules of Attention... [Insert Full App Content]',
  'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?auto=format&fit=crop&q=80&w=800',
  true
),
(
  'discovery-call-script',
  'High-Conversion Discovery Call Blueprint: From Greeting to Close',
  'Business',
  '5 min read',
  'The master control framework built for qualifying prospects, exposing deep operational pain, and positioning yourself as the only solution.',
  '## The Psychology of the Call... [Insert Full App Content]',
  'https://images.unsplash.com/photo-1639762681485-074b7f938ba0?auto=format&fit=crop&q=80&w=800',
  true
);
